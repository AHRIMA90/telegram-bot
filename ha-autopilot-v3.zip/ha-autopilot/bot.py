"""HA Autopilot v3 — aiogram 3 / aiohttp / sqlite. نقش‌ها فقط با آیدی عددی (OWNER_ID, ADMIN_IDS)."""
import asyncio, hashlib, hmac, html, json, logging, os, re, sqlite3, time
from collections import defaultdict, deque
from pathlib import Path
from urllib.parse import parse_qsl
import aiohttp
from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ChatType, ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.types import (CallbackQuery, ChatMemberUpdated, LabeledPrice, PreCheckoutQuery, FSInputFile, InlineKeyboardButton as Btn,
                           InlineKeyboardMarkup as Kb, LinkPreviewOptions, MenuButtonWebApp, Message, WebAppInfo)
try:
    from dotenv import load_dotenv; load_dotenv()
except ImportError:
    pass

TOKEN = os.getenv("BOT_TOKEN", ""); URL = os.getenv("WEBAPP_URL", "").rstrip("/"); PORT = int(os.getenv("PORT", "8080"))
OWNER_ID = int(os.getenv("OWNER_ID", "8553939238"))
ADMIN_IDS = {int(x) for x in os.getenv("ADMIN_IDS", "8389212775").replace(" ", "").split(",") if x}
STAFF = [OWNER_ID]  # فقط مالک درخواست‌ها و پنل را می‌بیند
BASE = Path(__file__).resolve().parent; DATA = Path(os.getenv("DATA_DIR", str(BASE))); DATA.mkdir(parents=True, exist_ok=True)
PHOTOS = DATA / "photos"; PHOTOS.mkdir(exist_ok=True)
MEDIA = DATA / "media"; MEDIA.mkdir(exist_ok=True)
HR = "┄┄┄┄┄┄┄┄┄┄┄┄┄┄"
MAX_LEN = 4096; INIT_TTL = 3600
if not TOKEN or not URL:
    raise SystemExit("BOT_TOKEN و WEBAPP_URL را در .env تنظیم کنید.")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s"); log = logging.getLogger("ap")
bot = Bot(TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML)); dp = Dispatcher()
NOPREV = LinkPreviewOptions(is_disabled=True)

db = sqlite3.connect(DATA / "autopilot.db", check_same_thread=False); db.row_factory = sqlite3.Row
db.executescript("""
CREATE TABLE IF NOT EXISTS channels(chat_id INTEGER PRIMARY KEY, owner INTEGER NOT NULL, title TEXT, username TEXT, members INTEGER DEFAULT 0, created INTEGER);
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY AUTOINCREMENT, owner INTEGER NOT NULL, chat_id INTEGER NOT NULL, text TEXT NOT NULL, status TEXT NOT NULL, run_at INTEGER, created INTEGER, error TEXT);
CREATE INDEX IF NOT EXISTS ix_posts_due ON posts(status, run_at);
CREATE INDEX IF NOT EXISTS ix_posts_owner ON posts(owner, created);
CREATE TABLE IF NOT EXISTS access(user_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT, status TEXT DEFAULT 'new', plan TEXT DEFAULT 'free', created INTEGER, last_req INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS referrals(invited_id INTEGER PRIMARY KEY, inviter_id INTEGER NOT NULL, created INTEGER);
CREATE INDEX IF NOT EXISTS ix_ref ON referrals(inviter_id);
CREATE TABLE IF NOT EXISTS force_channels(chat_id INTEGER PRIMARY KEY, title TEXT, link TEXT);
CREATE TABLE IF NOT EXISTS notif(user_id INTEGER, chat_id INTEGER, message_id INTEGER);
CREATE TABLE IF NOT EXISTS flow(user_id INTEGER PRIMARY KEY, data TEXT);
CREATE TABLE IF NOT EXISTS ai_cfg(chat_id INTEGER PRIMARY KEY, owner INTEGER, mode TEXT, topic TEXT, tone TEXT, publish TEXT, enabled INTEGER, times TEXT, per_day INTEGER, profile TEXT, profile_at INTEGER, last_slot TEXT);
CREATE TABLE IF NOT EXISTS ai_samples(id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER, text TEXT, created INTEGER);
CREATE INDEX IF NOT EXISTS ix_smp ON ai_samples(chat_id, id);
CREATE TABLE IF NOT EXISTS ai_log(user_id INTEGER, ts INTEGER);
CREATE TABLE IF NOT EXISTS drafts(id INTEGER PRIMARY KEY AUTOINCREMENT, owner INTEGER, chat_id INTEGER, text TEXT, status TEXT, created INTEGER);
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, method TEXT, amount INTEGER, status TEXT, created INTEGER, file_id TEXT, ref TEXT);
CREATE TABLE IF NOT EXISTS codes(code TEXT PRIMARY KEY, kind TEXT, value INTEGER, max_uses INTEGER, used INTEGER DEFAULT 0, created INTEGER);
CREATE TABLE IF NOT EXISTS code_uses(code TEXT, user_id INTEGER, PRIMARY KEY(code, user_id));
CREATE TABLE IF NOT EXISTS ch_stats(chat_id INTEGER, day INTEGER, members INTEGER, PRIMARY KEY(chat_id, day));
CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, status TEXT, created INTEGER, last_at INTEGER);
CREATE TABLE IF NOT EXISTS ticket_msgs(id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER, from_owner INTEGER, text TEXT, created INTEGER);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, actor INTEGER, action TEXT, target TEXT, created INTEGER);
""")
try: db.execute("ALTER TABLE access ADD COLUMN last_req INTEGER DEFAULT 0")
except sqlite3.OperationalError: pass
try: db.execute("ALTER TABLE access ADD COLUMN special_until INTEGER DEFAULT 0")
except sqlite3.OperationalError: pass
for col in ("support TEXT DEFAULT ''", "chan TEXT DEFAULT ''", "sig TEXT DEFAULT ''", "sig_every INTEGER DEFAULT 1", "sig_asked INTEGER DEFAULT 0"):
    try: db.execute("ALTER TABLE ai_cfg ADD COLUMN " + col)
    except sqlite3.OperationalError: pass
for tb, col in (("posts", "html INTEGER DEFAULT 0"), ("posts", "media TEXT"), ("posts", "media_type TEXT"), ("posts", "btn_text TEXT"), ("posts", "btn_url TEXT"), ("drafts", "run_at INTEGER")):
    try: db.execute(f"ALTER TABLE {tb} ADD COLUMN {col}")
    except sqlite3.OperationalError: pass
try: db.execute("ALTER TABLE posts ADD COLUMN message_id INTEGER")
except sqlite3.OperationalError: pass
db.execute("UPDATE access SET status='new' WHERE status='pending' AND last_req=0")  # مهاجرت از نسخه قبل
db.execute("UPDATE posts SET status='scheduled' WHERE status='sending' AND run_at IS NOT NULL")
db.execute("UPDATE posts SET status='failed', error='interrupted' WHERE status='sending'")
db.commit()

def q(sql, a=()): return db.execute(sql, a).fetchall()
def run(sql, a=()):
    c = db.execute(sql, a); db.commit(); return c
def audit(actor, action, target=""): run("INSERT INTO audit(actor,action,target,created) VALUES(?,?,?,?)", (actor, action, str(target), int(time.time())))
def role(uid): return "owner" if uid == OWNER_ID else "admin" if uid in ADMIN_IDS else "user"
FA = {"owner": "مالک", "admin": "ادمین"}
def owner(uid): return uid == OWNER_ID
def pair(a, b): return [b, a]  # تلگرام دکمه‌ها را چپ‌به‌راست می‌چیند؛ برای فارسی معکوس می‌کنیم
def setting(k, d="1"):
    r = q("SELECT value FROM settings WHERE key=?", (k,)); return r[0][0] if r else d
def set_setting(k, v): run("INSERT OR REPLACE INTO settings VALUES(?,?)", (k, str(v)))
def ago_fa(t):
    d = max(0, int(time.time()) - int(t))
    return "لحظاتی پیش" if d < 60 else f"{d // 60} دقیقه پیش" if d < 3600 else f"{d // 3600} ساعت پیش" if d < 86400 else f"{d // 86400} روز پیش"
def staff(uid): return role(uid) != "user"
def set_flow(uid, **d): run("INSERT OR REPLACE INTO flow VALUES(?,?)", (uid, json.dumps(d)))
def get_flow(uid):
    r = q("SELECT data FROM flow WHERE user_id=?", (uid,)); return json.loads(r[0][0]) if r else {}
def clear_flow(uid): run("DELETE FROM flow WHERE user_id=?", (uid,))
def status_of(uid):
    if staff(uid): return "approved"
    r = q("SELECT status FROM access WHERE user_id=?", (uid,)); return r[0][0] if r else "new"
def referral_count(uid):
    return q("SELECT COUNT(*) n FROM referrals r JOIN access a ON a.user_id=r.invited_id WHERE r.inviter_id=? AND a.status='approved'", (uid,))[0]["n"]
def ensure_user(u):
    run("""INSERT INTO access(user_id,username,first_name,status,plan,created) VALUES(?,?,?,?,?,?)
           ON CONFLICT(user_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name""",
        (u.id, (u.username or "").lower(), u.first_name, "approved" if staff(u.id) else "new", "free", int(time.time())))
    if staff(u.id): run("UPDATE access SET status='approved' WHERE user_id=?", (u.id,))
def reward(inviter):
    if staff(inviter): return False
    need = max(1, S("ref_needed")); rounds = int(setting(f"refrw:{inviter}", "0")); n = referral_count(inviter); got = False
    while n - rounds * need >= need: rounds += 1; grant_special(inviter, S("ref_days")); got = True
    set_setting(f"refrw:{inviter}", rounds); return got
def render_text(raw):
    t = html.escape(raw, quote=False)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t, flags=re.S); t = re.sub(r"__(.+?)__", r"<i>\1</i>", t, flags=re.S)
    return re.sub(r"`(.+?)`", r"<code>\1</code>", t, flags=re.S)
TAGRE = re.compile(r'<(/?)(b|i|u|s|code|pre|blockquote|tg-spoiler|a)(?:\s+href="([^"\s<>]*)")?\s*>')
def clean_html(t):
    out, stack, pos = [], [], 0
    def esc(x): return re.sub(r"&(?!amp;|lt;|gt;|quot;|#\d+;)", "&amp;", x).replace("<", "&lt;").replace(">", "&gt;")
    for m in TAGRE.finditer(t or ""):
        out.append(esc(t[pos:m.start()])); pos = m.end(); close, tag, href = m.group(1), m.group(2), m.group(3)
        if close:
            if tag in stack:
                while stack[-1] != tag: out.append(f"</{stack.pop()}>")
                stack.pop(); out.append(f"</{tag}>")
        else:
            if tag == "a":
                if not (href and re.match(r"(https?://|tg://)", href)): continue
                out.append(f'<a href="{href}">')
            else: out.append(f"<{tag}>")
            stack.append(tag)
    out.append(esc((t or "")[pos:]))
    while stack: out.append(f"</{stack.pop()}>")
    return "".join(out)
def plain(t): return html.unescape(re.sub(r"<[^>]+>", "", t or ""))
def tfmt(ts): return time.strftime("%Y/%m/%d %H:%M", time.gmtime(int(ts) + 12600))
def plan_fa(uid, plan): return FA.get(role(uid)) or ("ویژه" if is_special(uid) else "رایگان")

# ── جوین اجباری ──
JC = {}
async def missing(uid, force=False):
    if staff(uid): return []
    c = JC.get(uid)
    if c and not force and time.time() - c[0] < 30: return c[1]
    out = []
    for f in q("SELECT * FROM force_channels"):
        try:
            m = await bot.get_chat_member(f["chat_id"], uid)
            if m.status in ("left", "kicked"): out.append(dict(f))
        except Exception: pass
    JC[uid] = (time.time(), out); return out

async def add_force(ref):
    ref = str(ref).strip(); ref = re.sub(r"^https?://t\.me/", "", ref).lstrip("@")
    chat = await bot.get_chat(int(ref) if re.fullmatch(r"-?\d+", ref) else "@" + ref)
    me = await bot.get_me(); m = await bot.get_chat_member(chat.id, me.id)
    if m.status not in ("administrator", "creator"): raise ValueError("ربات باید در آن کانال ادمین باشد")
    link = f"https://t.me/{chat.username}" if chat.username else await bot.export_chat_invite_link(chat.id)
    run("INSERT OR REPLACE INTO force_channels VALUES(?,?,?)", (chat.id, chat.title, link)); JC.clear(); return chat.title

# ── امنیت وب ──
def verify_init(init):
    try:
        d = dict(parse_qsl(init, keep_blank_values=True)); got = d.pop("hash", "")
        chk = "\n".join(f"{k}={v}" for k, v in sorted(d.items()))
        sec = hmac.new(b"WebAppData", TOKEN.encode(), hashlib.sha256).digest()
        if not got or not hmac.compare_digest(hmac.new(sec, chk.encode(), hashlib.sha256).hexdigest(), got): return None
        if time.time() - int(d.get("auth_date", 0)) > INIT_TTL: return None
        return json.loads(d["user"])
    except Exception: return None
def jerr(msg, status=400, **x): return web.json_response({"error": msg, **x}, status=status)
HITS = defaultdict(deque)
def limited(uid, n=90, per=60):
    d = HITS[uid]; now = time.time()
    while d and now - d[0] > per: d.popleft()
    d.append(now); return len(d) > n
CSP = ("default-src 'self'; script-src 'self' 'unsafe-inline' https://telegram.org; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
       "font-src https://fonts.gstatic.com; img-src 'self' data: blob: https:; media-src 'self' blob:; connect-src 'self'; frame-ancestors https://*.telegram.org https://web.telegram.org; base-uri 'none'")

@web.middleware
async def mw(request, handler):
    if request.path.startswith("/api/"):
        if request.method == "POST" and request.path != "/api/upload" and (request.content_length is None or request.content_length > 65536): return jerr("حجم درخواست نامعتبر است", 413)
        user = verify_init(request.headers.get("X-Init-Data", ""))
        if not user: return jerr("احراز هویت نامعتبر است", 401)
        uid = user["id"]
        if limited(uid): return jerr("درخواست‌های زیاد؛ کمی صبر کنید", 429)
        request["user"] = user; ensure_user_dict(user)
        st = status_of(uid)
        if st == "banned": return jerr("حساب شما مسدود شده است", 403, code="banned")
        if st != "approved": return jerr("برای استفاده باید ادمین یا مالک مجوز شما را تأیید کند", 403, code=st)
        miss = await missing(uid)
        if miss: return jerr("ابتدا در کانال‌های زیر عضو شوید", 403, code="join", channels=[{"title": m["title"], "link": m["link"]} for m in miss])
    try: resp = await handler(request)
    except web.HTTPException as e: resp = e
    resp.headers.update({"Content-Security-Policy": CSP, "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer",
                         "Strict-Transport-Security": "max-age=31536000", "Cache-Control": resp.headers.get("Cache-Control", "no-store")})
    return resp
def ensure_user_dict(u):
    run("""INSERT INTO access(user_id,username,first_name,status,plan,created) VALUES(?,?,?,?,?,?)
           ON CONFLICT(user_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name""",
        (u["id"], (u.get("username") or "").lower(), u.get("first_name"), "approved" if staff(u["id"]) else "new", "free", int(time.time())))

# ── انتشار ──
def add_post(uid, cid, text, status, run_at=None, media=None, mtype=None, bt=None, bu=None):
    return run("INSERT INTO posts(owner,chat_id,text,status,run_at,created,html,media,media_type,btn_text,btn_url) VALUES(?,?,?,?,?,?,1,?,?,?,?)",
               (uid, cid, text, status, run_at, int(time.time()), media, mtype, bt, bu)).lastrowid
def post_kb(row):
    if row["btn_text"] and row["btn_url"]: return Kb(inline_keyboard=[[Btn(text=row["btn_text"], url=row["btn_url"])]])
def cleanup_media(m):
    if m and m.startswith("f:") and not q("SELECT 1 FROM posts WHERE media=? AND status IN ('scheduled','sending')", (m,)): (MEDIA / m[2:]).unlink(missing_ok=True)
async def send_row(row, txt, kb):
    m = row["media"]
    if not m: return await bot.send_message(row["chat_id"], txt, reply_markup=kb)
    src = m[3:] if m.startswith("tg:") else FSInputFile(MEDIA / m[2:]); send = bot.send_photo if row["media_type"] == "photo" else bot.send_video
    kw = {"photo": src} if row["media_type"] == "photo" else {"video": src}
    if len(plain(txt)) <= 1024: return await send(row["chat_id"], caption=txt or None, reply_markup=kb, **kw)
    await send(row["chat_id"], **kw); return await bot.send_message(row["chat_id"], txt, reply_markup=kb)
async def publish(pid):
    row = q("SELECT * FROM posts WHERE id=?", (pid,))[0]; txt = row["text"] if row["html"] else render_text(row["text"]); kb = post_kb(row)
    try:
        try: msg = await send_row(row, txt, kb)
        except Exception as e:
            if "entities" not in str(e).lower(): raise
            msg = await send_row(row, html.escape(plain(txt), quote=False), kb)
        run("UPDATE posts SET status='sent', error=NULL, message_id=? WHERE id=?", (msg.message_id, pid))
        cleanup_media(row["media"]); asyncio.create_task(notify_post(row)); return True
    except Exception as e:
        run("UPDATE posts SET status='failed', error=? WHERE id=?", (str(e)[:200], pid)); return False
async def user_delete(uid, pid):
    r = q("SELECT status,media FROM posts WHERE id=? AND owner=?", (pid, uid))
    if not r: return False
    if r[0]["status"] == "scheduled": run("DELETE FROM posts WHERE id=?", (pid,)); cleanup_media(r[0]["media"]); return True
    return await delete_post(pid) if r[0]["status"] in ("sent", "failed") else False
async def user_edit(uid, pid, t):
    t = clean_html(t); r = q("SELECT * FROM posts WHERE id=? AND owner=? AND status IN ('sent','scheduled')", (pid, uid))
    if not r: return "پست پیدا نشد"
    r = r[0]
    if not plain(t).strip() and not r["media"]: return "متن خالی است"
    if len(plain(t)) > (1024 if r["media"] else MAX_LEN): return "متن بیش از حد طولانی است"
    if r["status"] == "sent":
        try:
            if r["media"] and len(plain(t)) <= 1024: await bot.edit_message_caption(chat_id=r["chat_id"], message_id=r["message_id"], caption=t, reply_markup=post_kb(r))
            else: await bot.edit_message_text(t, chat_id=r["chat_id"], message_id=r["message_id"], reply_markup=post_kb(r))
        except Exception as e:
            if "not modified" not in str(e).lower(): return "ویرایش در کانال ممکن نشد (ممکن است پست قبلاً پاک شده باشد)"
    run("UPDATE posts SET text=?, html=1 WHERE id=?", (t, pid)); audit(uid, "edit_post", pid); return None
async def delete_today(uid):
    n = 0
    for r in q("SELECT id FROM posts WHERE owner=? AND status IN ('sent','scheduled') AND created>?", (uid, int(time.time()) - 86400)):
        if await user_delete(uid, r["id"]): n += 1
        await asyncio.sleep(0.1)
    return n
async def scheduler():
    while True:
        try:
            for r in q("SELECT id FROM posts WHERE status='scheduled' AND run_at<=?", (int(time.time()),)):
                if run("UPDATE posts SET status='sending' WHERE id=? AND status='scheduled'", (r["id"],)).rowcount: await publish(r["id"])
                await asyncio.sleep(0.05)
        except Exception: log.exception("scheduler")
        await asyncio.sleep(15)
async def backup_loop():
    while True:
        await asyncio.sleep(86400)
        try:
            f = DATA / "backup.db"; dst = sqlite3.connect(f); db.backup(dst); dst.close()
            await bot.send_document(OWNER_ID, FSInputFile(f, filename=f"autopilot-{time.strftime('%Y%m%d')}.db"), caption="🗄 بکاپ روزانه"); f.unlink()
        except Exception: log.exception("backup")

# ── سهمیه، ضد سوءاستفاده، اعلان‌ها ──
def cap(uid):
    if owner(uid): return 10**6
    r = q("SELECT plan FROM access WHERE user_id=?", (uid,))
    return S("cap_special") if premium(uid) else S("cap_free")
def used_today(uid): return q("SELECT COUNT(*) n FROM posts WHERE owner=? AND created>? AND status NOT IN ('failed','deleted')", (uid, int(time.time()) - 86400))[0]["n"]
async def abuse(uid):
    if staff(uid): return False
    r = q("SELECT value FROM settings WHERE key=?", (f"rs:{uid}",))
    if r and int(r[0][0]) > time.time(): return True
    if q("SELECT COUNT(*) n FROM posts WHERE owner=? AND created>?", (uid, int(time.time()) - 300))[0]["n"] >= 10:
        set_setting(f"rs:{uid}", int(time.time()) + 3600); audit(0, "auto_restrict", uid)
        a = q("SELECT first_name FROM access WHERE user_id=?", (uid,))
        try: await bot.send_message(OWNER_ID, f"🚨 <b>رفتار مشکوک</b>\nکاربر {html.escape(a[0][0] or '') if a else ''} (<code>{uid}</code>) در ۵ دقیقه بیش از ۱۰ پست ساخت و یک ساعت محدود شد.",
            reply_markup=Kb(inline_keyboard=[pair(B("⛔️ مسدود", f"o:ban:{uid}"), B("✅ رفع محدودیت", f"o:free:{uid}"))]))
        except Exception: pass
        return True
    return False
async def notify_post(row):
    if row["owner"] == OWNER_ID or setting("notify") != "1": return
    a = q("SELECT first_name,username FROM access WHERE user_id=?", (row["owner"],)); c = q("SELECT title FROM channels WHERE chat_id=?", (row["chat_id"],))
    nm = html.escape((a[0]["first_name"] or "") if a else "") + (f" (@{a[0]['username']})" if a and a[0]["username"] else "")
    try: await bot.send_message(OWNER_ID, f"📝 <b>پست جدید</b>\n👤 {nm} • <code>{row['owner']}</code>\n📢 {html.escape(c[0]['title'] or '') if c else '—'}\n\n{html.escape(plain(row['text'])[:300])}",
        reply_markup=Kb(inline_keyboard=[pair(B("🗑 حذف پست", f"o:del:{row['id']}"), B("⛔️ مسدود کاربر", f"o:ban:{row['owner']}"))]))
    except Exception: pass
def activity(uid=None, limit=30, before=0):
    rows = q("""SELECT p.id,p.owner,p.text,p.status,p.created,p.run_at,p.message_id,a.first_name,a.username,c.title FROM posts p
        LEFT JOIN access a ON a.user_id=p.owner LEFT JOIN channels c ON c.chat_id=p.chat_id
        WHERE (?1 IS NULL OR p.owner=?1) AND (?2=0 OR p.id<?2) ORDER BY p.id DESC LIMIT ?3""", (uid, before, limit))
    return [{"id": r["id"], "owner": r["owner"], "name": r["first_name"] or str(r["owner"]), "username": r["username"] or "", "channel": r["title"] or "کانال حذف‌شده",
             "text": plain(r["text"]), "status": "sent" if r["status"] == "sending" else r["status"], "t": r["run_at"] if r["status"] == "scheduled" else r["created"], "can_delete": bool(r["message_id"]) and r["status"] == "sent"} for r in rows]
async def user_action(me, uid, act):
    if staff(uid): return "روی مالک/ادمین نمی‌توان عملیات انجام داد"
    if not q("SELECT 1 FROM access WHERE user_id=?", (uid,)): return "کاربر پیدا نشد"
    m = {"approve": ("status", "approved"), "deny": ("status", "denied"), "ban": ("status", "banned"), "unban": ("status", "new"), "special": ("plan", "special"), "free": ("plan", "free")}
    if act not in m: return "عملیات نامعتبر است"
    col, val = m[act]; run(f"UPDATE access SET {col}=? WHERE user_id=?", (val, uid)); audit(me, act, uid); JC.pop(uid, None)
    if act == "approve":
        for r in q("SELECT inviter_id FROM referrals WHERE invited_id=?", (uid,)):
            if reward(r["inviter_id"]):
                try: await bot.send_message(r["inviter_id"], f"🎉 {S('ref_needed')} دعوت کامل شد؛ {S('ref_days')} روز پلن ویژه فعال شد.")
                except Exception: pass
        try: await bot.send_message(uid, "✅ دسترسی شما تأیید شد. /start را بزنید.")
        except Exception: pass
async def report_loop():
    while True:
        now = time.time(); nxt = now // 86400 * 86400 + 20.5 * 3600
        if nxt <= now: nxt += 86400
        await asyncio.sleep(nxt - now)
        if setting("report") != "1": continue
        t = int(time.time()) - 86400
        def n(sql, *a): return q(sql, a or (t,))[0]["n"]
        try: await bot.send_message(OWNER_ID, "🌙 <b>گزارش روزانه</b>\n\n" + f"کاربر جدید: {n('SELECT COUNT(*) n FROM access WHERE created>?')}\n" + f"درخواست در انتظار: {n('SELECT COUNT(*) n FROM access WHERE status=?', 'pending')}\n"
            + f"پست منتشرشده: {n('SELECT COUNT(*) n FROM posts WHERE status=\'sent\' AND created>?')}\n" + f"پست ناموفق: {n('SELECT COUNT(*) n FROM posts WHERE status=\'failed\' AND created>?')}")
        except Exception: log.exception("report")

# ── API کاربر ──
async def api_state(request):
    u = request["user"]; uid = u["id"]; acc = q("SELECT plan FROM access WHERE user_id=?", (uid,))
    plan = acc[0]["plan"] if acc else "free"
    chans = q("SELECT chat_id,title,username,members FROM channels WHERE owner=? ORDER BY created DESC", (uid,))
    cnt = {r["status"]: r["n"] for r in q("SELECT status,COUNT(*) n FROM posts WHERE owner=? GROUP BY status", (uid,))}
    sent, failed = cnt.get("sent", 0), cnt.get("failed", 0)
    t0 = int(time.time()) // 86400 * 86400; lo = t0 - 29 * 86400
    days = [{"t": lo + i * 86400, "ok": 0, "bad": 0} for i in range(30)]; hours = [0] * 24
    for r in q("SELECT status,created FROM posts WHERE owner=? AND created>=? AND status IN ('sent','failed')", (uid, lo)):
        days[min((r["created"] - lo) // 86400, 29)]["ok" if r["status"] == "sent" else "bad"] += 1
        if r["status"] == "sent": hours[(r["created"] // 3600) % 24] += 1
    act = q("SELECT p.text,p.status,p.created,p.run_at,c.title FROM posts p LEFT JOIN channels c ON c.chat_id=p.chat_id WHERE p.owner=? ORDER BY p.id DESC LIMIT 8", (uid,))
    me = await bot.get_me()
    return web.json_response({"bot": me.username, "user": {"name": u.get("first_name", ""), "username": u.get("username", ""), "id": uid, "role": role(uid),
        "plan": plan_fa(uid, plan), "referrals": referral_count(uid), "used": used_today(uid), "cap": min(cap(uid), 99999), "ref_needed": S("ref_needed"), "ref_days": S("ref_days"), "ref_progress": referral_count(uid) % max(1, S("ref_needed")), "ref_rounds": int(setting(f"refrw:{uid}", "0"))},
        "stats": {"posted": sent, "scheduled": cnt.get("scheduled", 0), "channels": len(chans), "rate": round(sent * 100 / (sent + failed)) if sent + failed else 100},
        "channels": [{"id": c["chat_id"], "title": c["title"], "username": c["username"], "members": c["members"], "growth": [g["m"] for g in growth(c["chat_id"], 14)], "delta7": delta7(c["chat_id"], c["members"]), "link": "https://t.me/" + c["username"] if c["username"] else ""} for c in chans],
        "days": days, "hours": hours, "activity": [{"text": (a["text"] or "")[:60], "ch": a["title"] or "کانال حذف‌شده", "status": "sent" if a["status"] == "sending" else a["status"], "t": a["run_at"] if a["status"] == "scheduled" else a["created"]} for a in act]})

async def api_photo(request):
    uid = request["user"]["id"]; f = PHOTOS / f"{uid}.jpg"
    if not (f.exists() and time.time() - f.stat().st_mtime < 21600):
        try:
            ph = await bot.get_user_profile_photos(uid, limit=1)
            if not ph.total_count: return web.Response(status=204)
            await bot.download(ph.photos[0][-1].file_id, destination=f)
        except Exception: return web.Response(status=204)
    return web.FileResponse(f, headers={"Cache-Control": "private, max-age=3600"})

async def api_post(request):
    uid = request["user"]["id"]
    try:
        b = await request.json(); text = clean_html(str(b.get("text", "")).strip()); ids = [int(x) for x in b.get("chat_ids", [])]
        run_at = int(b["run_at"]) if b.get("run_at") else None; media = b.get("media") or None
        bt = str(b.get("btn_text") or "").strip()[:40]; bu = str(b.get("btn_url") or "").strip()
    except Exception: return jerr("درخواست نامعتبر است")
    mtype = None
    if media:
        if not re.fullmatch(rf"{uid}_[A-Za-z0-9_-]+\.(jpg|png|webp|mp4)", media) or not (MEDIA / media).exists(): return jerr("فایل رسانه نامعتبر است")
        mtype = "video" if media.endswith("mp4") else "photo"; media = "f:" + media
    if bu.startswith("@"): bu = "https://t.me/" + bu[1:]
    if bool(bt) != bool(bu) or (bu and not re.match(r"https?://[^\s]+$", bu)): return jerr("برای دکمه، هم متن و هم لینک معتبر لازم است")
    if not plain(text).strip() and not media: return jerr("متن پست خالی است")
    if len(plain(text)) > (1024 if media else MAX_LEN): return jerr("متن پست بیش از حد طولانی است" + (" (با رسانه حداکثر ۱۰۲۴ کاراکتر)" if media else ""))
    if not ids or len(ids) > 20: return jerr("کانال نامعتبر است")
    if not set(ids) <= {r["chat_id"] for r in q("SELECT chat_id FROM channels WHERE owner=?", (uid,))}: return jerr("به این کانال دسترسی ندارید", 403)
    if await abuse(uid): return jerr("به‌دلیل ارسال بیش‌ازحد، موقتاً محدود شده‌اید", 429)
    if used_today(uid) + len(ids) > cap(uid): return jerr(f"سقف ارسال روزانه ({cap(uid)} پست) پر شده است", 429)
    if run_at and run_at < int(time.time()) + 20: return jerr("زمان انتشار باید در آینده باشد")
    ok = failed = 0
    for cid in ids:
        if run_at: add_post(uid, cid, text, "scheduled", run_at, media, mtype, bt or None, bu or None); ok += 1
        else:
            if await publish(add_post(uid, cid, text, "sending", None, media, mtype, bt or None, bu or None)): ok += 1
            else: failed += 1
    return web.json_response({"ok": ok, "failed": failed})
async def api_upload(request):
    uid = request["user"]["id"]; rd = await request.multipart(); f = await rd.next()
    if not f or f.name != "file": return jerr("فایلی ارسال نشد")
    ct = f.headers.get("Content-Type", ""); ext = {"image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "video/mp4": "mp4", "video/quicktime": "mp4"}.get(ct)
    if not ext: return jerr("فقط عکس (JPG، PNG، WebP) یا ویدیو (MP4) مجاز است")
    kind = "video" if ext == "mp4" else "photo"; limit = (40 if kind == "video" else 10) * 2**20; name = f"{uid}_{os.urandom(8).hex()}.{ext}"; size = 0
    with open(MEDIA / name, "wb") as fh:
        while True:
            ch = await f.read_chunk(65536)
            if not ch: break
            size += len(ch)
            if size > limit: fh.close(); (MEDIA / name).unlink(missing_ok=True); return jerr(f"حجم فایل بیش از {limit // 2**20} مگابایت است")
            fh.write(ch)
    return web.json_response({"media": name, "type": kind})
async def api_posts(request):
    uid = request["user"]["id"]; kind = request.query.get("kind", "sent"); kind = kind if kind in ("sent", "scheduled", "failed") else "sent"
    rows = q("SELECT p.id,p.text,p.html,p.status,p.media,p.btn_text,p.created,p.run_at,c.title FROM posts p LEFT JOIN channels c ON c.chat_id=p.chat_id WHERE p.owner=? AND p.status=? ORDER BY p.id DESC LIMIT 30", (uid, kind))
    return web.json_response({"items": [{"id": r["id"], "html": r["text"] if r["html"] else render_text(r["text"]), "preview": plain(r["text"])[:90], "ch": r["title"] or "کانال حذف‌شده",
        "t": r["run_at"] if kind == "scheduled" else r["created"], "media": bool(r["media"]), "btn": r["btn_text"] or ""} for r in rows]})
async def api_posts_act(request):
    uid = request["user"]["id"]
    try: b = await request.json(); act = b["action"]
    except Exception: return jerr("درخواست نامعتبر است")
    if act == "delete_today": return web.json_response({"ok": True, "n": await delete_today(uid)})
    try: pid = int(b["id"])
    except Exception: return jerr("درخواست نامعتبر است")
    if act == "delete":
        if not await user_delete(uid, pid): return jerr("پست پیدا نشد", 404)
    elif act == "edit":
        err = await user_edit(uid, pid, str(b.get("text", "")))
        if err: return jerr(err)
    elif act == "now":
        if not q("SELECT 1 FROM posts WHERE id=? AND owner=? AND status='scheduled'", (pid, uid)): return jerr("پست پیدا نشد", 404)
        if run("UPDATE posts SET status='sending' WHERE id=? AND status='scheduled'", (pid,)).rowcount: await publish(pid)
    else: return jerr("عملیات نامعتبر است")
    return web.json_response({"ok": True})

async def api_queue(request):
    rows = q("SELECT p.id,p.text,p.run_at,c.title FROM posts p LEFT JOIN channels c ON c.chat_id=p.chat_id WHERE p.owner=? AND p.status='scheduled' ORDER BY p.run_at LIMIT 50", (request["user"]["id"],))
    return web.json_response({"items": [{"id": r["id"], "text": r["text"][:80], "t": r["run_at"], "ch": r["title"] or "—"} for r in rows]})
async def api_queue_act(request):
    uid = request["user"]["id"]
    try: b = await request.json(); pid = int(b["id"]); act = b["action"]
    except Exception: return jerr("درخواست نامعتبر است")
    if not q("SELECT 1 FROM posts WHERE id=? AND owner=? AND status='scheduled'", (pid, uid)): return jerr("پست پیدا نشد", 404)
    if act == "cancel": run("DELETE FROM posts WHERE id=?", (pid,))
    elif act == "now":
        if run("UPDATE posts SET status='sending' WHERE id=? AND status='scheduled'", (pid,)).rowcount: await publish(pid)
    else: return jerr("عملیات نامعتبر است")
    return web.json_response({"ok": True})

# ── API مدیریت (ادمین + مالک) ──
def need_staff(request): return owner(request["user"]["id"])
async def api_adm_overview(request):
    if not need_staff(request): return jerr("دسترسی ندارید", 403)
    us = {r["status"]: r["n"] for r in q("SELECT status,COUNT(*) n FROM access GROUP BY status")}
    ps = {r["status"]: r["n"] for r in q("SELECT status,COUNT(*) n FROM posts GROUP BY status")}
    sent, fail = ps.get("sent", 0), ps.get("failed", 0)
    au = q("SELECT actor,action,target,created FROM audit ORDER BY id DESC LIMIT 15")
    return web.json_response({"users": us, "posts": ps, "channels": q("SELECT COUNT(*) n FROM channels")[0]["n"], "err": round(fail * 100 / (sent + fail)) if sent + fail else 0, "notify": setting("notify") == "1", "pay": {"stars": q("SELECT COALESCE(SUM(amount),0) n FROM payments WHERE method='stars' AND status='paid'")[0]["n"], "card": q("SELECT COUNT(*) n FROM payments WHERE method='card' AND status='paid'")[0]["n"], "pending": q("SELECT COUNT(*) n FROM payments WHERE status='pending'")[0]["n"]}, "report": setting("report") == "1",
        "audit": [{"actor": a["actor"], "action": a["action"], "target": a["target"], "t": a["created"]} for a in au]})
async def api_adm_user(request):
    me = request["user"]["id"]
    if not owner(me): return jerr("دسترسی ندارید", 403)
    try: b = await request.json(); uid = int(b["user_id"]); act = b["action"]
    except Exception: return jerr("درخواست نامعتبر است")
    err = await user_action(me, uid, act)
    return jerr(err) if err else web.json_response({"ok": True})
async def api_adm_broadcast(request):
    me = request["user"]["id"]
    if not owner(me): return jerr("دسترسی ندارید", 403)
    try: text = str((await request.json())["text"]).strip()[:MAX_LEN]
    except Exception: return jerr("درخواست نامعتبر است")
    if not text: return jerr("متن خالی است")
    audit(me, "broadcast", text[:40]); asyncio.create_task(broadcast(html.escape(text, quote=False), me)); return web.json_response({"ok": True})
async def broadcast(text, by):
    ok = 0
    for r in q("SELECT user_id FROM access WHERE status='approved'"):
        try: await bot.send_message(r["user_id"], text); ok += 1
        except Exception: pass
        await asyncio.sleep(0.05)
    try: await bot.send_message(by, f"📣 پیام همگانی برای {ok} نفر ارسال شد.")
    except Exception: pass
async def api_adm_force(request):
    me = request["user"]["id"]
    if me != OWNER_ID: return jerr("فقط مالک به این بخش دسترسی دارد", 403)
    if request.method == "GET":
        return web.json_response({"items": [dict(r) for r in q("SELECT chat_id,title,link FROM force_channels")]})
    try: b = await request.json()
    except Exception: return jerr("درخواست نامعتبر است")
    if b.get("action") == "remove":
        run("DELETE FROM force_channels WHERE chat_id=?", (int(b["chat_id"]),)); JC.clear(); audit(me, "force_remove", b["chat_id"])
    else:
        try: t = await add_force(b.get("ref", "")); audit(me, "force_add", t)
        except Exception as e: return jerr(str(e) if isinstance(e, ValueError) else "کانال پیدا نشد؛ ربات باید در آن ادمین باشد")
    return web.json_response({"ok": True})
async def api_adm_activity(request):
    if not need_staff(request): return jerr("دسترسی ندارید", 403)
    try: before = int(request.query.get("before", 0)); uid = int(request.query["user"]) if request.query.get("user") else None
    except ValueError: return jerr("درخواست نامعتبر است")
    return web.json_response({"items": activity(uid, 30, before)})
async def api_adm_detail(request):
    if not need_staff(request): return jerr("دسترسی ندارید", 403)
    try: uid = int(request.query["id"])
    except Exception: return jerr("درخواست نامعتبر است")
    a = q("SELECT user_id,username,first_name,status,plan,created FROM access WHERE user_id=?", (uid,))
    if not a: return jerr("کاربر پیدا نشد", 404)
    cs = q("SELECT title,username,members FROM channels WHERE owner=?", (uid,)); cnt = {r["status"]: r["n"] for r in q("SELECT status,COUNT(*) n FROM posts WHERE owner=? GROUP BY status", (uid,))}
    return web.json_response({"user": {**dict(a[0]), "role": role(uid), "referrals": referral_count(uid), "used": used_today(uid), "cap": min(cap(uid), 99999)},
        "channels": [dict(c) for c in cs], "counts": cnt, "posts": activity(uid, 8)})
async def api_adm_post(request):
    me = request["user"]["id"]
    if not owner(me): return jerr("دسترسی ندارید", 403)
    try: pid = int((await request.json())["id"])
    except Exception: return jerr("درخواست نامعتبر است")
    if not await delete_post(pid): return jerr("پست پیدا نشد", 404)
    audit(me, "delete_post", pid); return web.json_response({"ok": True})
async def delete_post(pid):
    r = q("SELECT chat_id,message_id,status FROM posts WHERE id=?", (pid,))
    if not r: return False
    if r[0]["message_id"]:
        try: await bot.delete_message(r[0]["chat_id"], r[0]["message_id"])
        except Exception: pass
    run("UPDATE posts SET status='deleted' WHERE id=?", (pid,)); return True
async def api_adm_setting(request):
    me = request["user"]["id"]
    if not owner(me): return jerr("دسترسی ندارید", 403)
    try: b = await request.json(); k = b["key"]; v = "1" if b["value"] in ("1", 1, True) else "0"
    except Exception: return jerr("درخواست نامعتبر است")
    if k not in ("notify", "report"): return jerr("کلید نامعتبر است")
    set_setting(k, v); audit(me, "setting_" + k, v); return web.json_response({"ok": True})
async def api_ai(request):
    uid = request["user"]["id"]; ok, why = can_ai(uid)
    ch = [{"id": c["chat_id"], "title": c["title"], "enabled": bool((cf := q("SELECT * FROM ai_cfg WHERE chat_id=?", (c["chat_id"],))) and cf[0]["enabled"]), "mode": cf[0]["mode"] if cf else "manual", "publish": cf[0]["publish"] if cf else "draft"} for c in q("SELECT chat_id,title FROM channels WHERE owner=?", (uid,))]
    dr = q("SELECT d.id,d.text,d.created,c.title FROM drafts d LEFT JOIN channels c ON c.chat_id=d.chat_id WHERE d.owner=? AND d.status='draft' ORDER BY d.id DESC LIMIT 10", (uid,))
    return web.json_response({"can": ok, "reason": why, "special": premium(uid) or owner(uid), "trial_left": trial_left(uid), "used": ai_today(uid), "quota": 0 if owner(uid) else S("quota_special"),
        "channels": ch, "batch": batch_list(uid), "drafts": [{"id": d["id"], "text": d["text"], "ch": d["title"] or "—", "t": d["created"]} for d in dr],
        "plans": {"stars": S("price_stars"), "card": S("price_card"), "days": S("special_days"), "quota": S("quota_special"), "channels": S("ai_channels_special"), "ref": S("ref_needed"), "ref_days": S("ref_days"), "cap_free": S("cap_free"), "cap_special": S("cap_special"), "trial": S("ai_trial")}})
async def api_ai_draft(request):
    uid = request["user"]["id"]
    try: b = await request.json(); did = int(b["id"]); act = b["action"]
    except Exception: return jerr("درخواست نامعتبر است")
    if act == "publish":
        if not await publish_draft(did, uid): return jerr("انتشار انجام نشد")
    elif act == "discard": run("UPDATE drafts SET status='rejected' WHERE id=? AND owner=? AND status='draft'", (did, uid))
    else: return jerr("عملیات نامعتبر است")
    return web.json_response({"ok": True})
async def api_ai_toggle(request):
    uid = request["user"]["id"]
    try: b = await request.json(); cid = int(b["chat_id"]); on = bool(b["enabled"])
    except Exception: return jerr("درخواست نامعتبر است")
    if not q("SELECT 1 FROM channels WHERE chat_id=? AND owner=?", (cid, uid)): return jerr("کانال پیدا نشد", 404)
    cfg = ensure_cfg(cid, uid)
    if on:
        ok, why = can_ai(uid)
        if not ok: return jerr(ERR[why], 403)
        if cfg["mode"] == "manual" and not cfg["topic"]: return jerr("ابتدا از دکمه «تنظیم» موضوع را در ربات مشخص کنید")
        if not (cfg["sig"] or cfg["support"] or cfg["chan"]) and not cfg["sig_asked"]:
            run("UPDATE ai_cfg SET sig_asked=1 WHERE chat_id=?", (cid,)); return jerr("آیدی پشتیبانی/کانال تنظیم نشده؛ از «تنظیم» اضافه کنید یا دوباره روشن کنید تا بدون آن فعال شود")
        if not cfg["enabled"] and q("SELECT COUNT(*) n FROM ai_cfg WHERE owner=? AND enabled=1", (uid,))[0]["n"] >= max_ai_channels(uid): return jerr("به سقف کانال هوشمند رسیده‌اید", 403)
    run("UPDATE ai_cfg SET enabled=? WHERE chat_id=?", (1 if on else 0, cid)); return web.json_response({"ok": True})
async def api_adm_settings(request):
    if not owner(request["user"]["id"]): return jerr("دسترسی ندارید", 403)
    if request.method == "POST":
        try: b = await request.json(); err = set_cfg(b["key"], b["value"])
        except Exception: return jerr("درخواست نامعتبر است")
        if err: return jerr(err)
        audit(request["user"]["id"], "set_" + b["key"], "")
    return web.json_response({"items": [{"key": k, "label": v[0], "value": str(S(k))} for k, v in SET.items()]})
async def index(_): return web.FileResponse(BASE / "index.html", headers={"Cache-Control": "no-cache"})

# ── ربات: پنل شیشه‌ای ──
def B(t, cb=None, url=None, app=None):
    return Btn(text=t, callback_data=cb) if cb else Btn(text=t, url=url) if url else Btn(text=t, web_app=WebAppInfo(url=app))
async def show(ev, text, rows=None):
    kb = Kb(inline_keyboard=rows) if rows else None
    if isinstance(ev, CallbackQuery):
        try: await ev.message.edit_text(text, reply_markup=kb, link_preview_options=NOPREV)
        except Exception: pass
        await ev.answer()
    else: await ev.answer(text, reply_markup=kb, link_preview_options=NOPREV)
BACK = [B("🔙 منوی اصلی", "m:main")]
def home_rows(uid):
    r = [[B("🚀 باز کردن مینی‌اپ", app=URL)], pair(B("✍️ پست جدید", "p:new"), B("🤖 هوش مصنوعی", "m:ai")), pair(B("📝 پست‌های من", "mp:list"), B("🕒 صف انتشار", "m:queue")),
         pair(B("📢 کانال‌های من", "m:ch"), B("📊 آمار من", "m:stats")), pair(B("💎 پلن ویژه", "m:buy"), B("🎁 دعوت دوستان", "m:ref")),
         pair(B("👤 حساب کاربری", "m:profile"), B("🆘 پشتیبانی", "tk:home")), [B("📖 راهنما", "m:help")]]
    if owner(uid): r.insert(1, [B("🛡 پنل مدیریت", "a:home")])
    return r
async def home(ev, uid, name):
    use = "" if owner(uid) else f"  •  امروز {used_today(uid)}/{cap(uid)} پست"
    await show(ev, f"💠 <b>HA Autopilot</b>\n{HR}\nسلام <b>{html.escape(name)}</b> 👋\nسطح: <b>{plan_fa(uid, '')}</b>{use}\n\nیکی از گزینه‌ها را انتخاب کن:", home_rows(uid))
async def gate(ev):
    """True اگر کاربر مجاز باشد؛ وگرنه صفحه مناسب را نشان می‌دهد."""
    u = ev.from_user; uid = u.id; ensure_user(u); st = status_of(uid)
    if st == "banned": await show(ev, "⛔️ حساب شما مسدود شده است."); return False
    if st != "approved":
        if st == "pending":
            await show(ev, "⏳ درخواست شما در انتظار تأیید ادمین یا مالک است. نتیجه از همین ربات اطلاع داده می‌شود.", [[B("🔄 بررسی وضعیت", "m:main")]])
        else:
            await show(ev, f"سلام <b>{html.escape(u.first_name or '')}</b> 👋\nبرای استفاده از ربات، ادمین یا مالک باید دسترسی شما را تأیید کند.\n\nℹ️ فعالیت شما در ربات برای مدیریت قابل مشاهده است.", [[B("🔐 درخواست مجوز استفاده", "r:req")]])
        return False
    miss = await missing(uid, force=True)
    if miss:
        await show(ev, "📌 برای ادامه، ابتدا در کانال‌های زیر عضو شوید و سپس «بررسی عضویت» را بزنید.",
                   [[B("📢 " + (m["title"] or "کانال"), url=m["link"])] for m in miss] + [[B("✅ بررسی عضویت", "m:main")]]); return False
    return True

@dp.message(CommandStart(), F.chat.type == ChatType.PRIVATE)
async def start(m: Message):
    u = m.from_user; arg = (m.text or "").split(maxsplit=1)[1:]; new = not q("SELECT 1 FROM access WHERE user_id=?", (u.id,)); ensure_user(u); clear_flow(u.id)
    if new and arg and arg[0].startswith("ref_") and arg[0][4:].isdigit():
        inv = int(arg[0][4:])
        if inv != u.id and q("SELECT 1 FROM access WHERE user_id=?", (inv,)): run("INSERT OR IGNORE INTO referrals VALUES(?,?,?)", (u.id, inv, int(time.time())))
    if await gate(m):
        if arg and arg[0] == "buy": return await buy_menu(m)
        if arg and arg[0] == "support": return await tk_home(m)
        if arg and arg[0].startswith("ai_") and arg[0][3:].lstrip("-").isdigit(): return await ai_channel(m, int(arg[0][3:]))
        await home(m, u.id, u.first_name or "دوست")
@dp.message(Command("menu", "profile", "post"), F.chat.type == ChatType.PRIVATE)
async def cmd_menu(m: Message):
    clear_flow(m.from_user.id)
    if await gate(m): await home(m, m.from_user.id, m.from_user.first_name or "دوست")

@dp.callback_query(F.data == "r:req")
async def req(c: CallbackQuery):
    u = c.from_user; ensure_user(u); st = status_of(u.id); now = int(time.time())
    if st in ("approved", "banned"): return await gate(c)
    last = q("SELECT last_req FROM access WHERE user_id=?", (u.id,))[0][0] or 0
    if st == "pending" or now - last < 60: return await c.answer("درخواست شما قبلاً ثبت شده است.", show_alert=True)
    run("UPDATE access SET status='pending', last_req=? WHERE user_id=?", (now, u.id)); run("DELETE FROM notif WHERE user_id=?", (u.id,))
    txt = f"🔐 <b>درخواست دسترسی جدید</b>\nنام: {html.escape(u.full_name)}\nآیدی: <code>{u.id}</code>\nیوزرنیم: {'@' + html.escape(u.username) if u.username else 'ندارد'}"
    kb = Kb(inline_keyboard=[pair(B("✅ تأیید", f"d:ok:{u.id}"), B("❌ رد", f"d:no:{u.id}")), [B("⛔️ مسدود", f"d:ban:{u.id}")]]); sent = 0
    for s in STAFF:
        try: msg = await bot.send_message(s, txt, reply_markup=kb); run("INSERT INTO notif VALUES(?,?,?)", (u.id, s, msg.message_id)); sent += 1
        except Exception: pass
    if not sent: run("UPDATE access SET status='new' WHERE user_id=?", (u.id,)); return await c.answer("فعلاً امکان ارسال درخواست نیست؛ بعداً دوباره تلاش کنید.", show_alert=True)
    await show(c, "✅ درخواست شما برای مدیریت ارسال شد. پس از تأیید، پیام می‌گیرید.", [[B("🔄 بررسی وضعیت", "m:main")]])

@dp.callback_query(F.data.startswith("d:"))
async def decide(c: CallbackQuery):
    me = c.from_user
    if not owner(me.id): return await c.answer("فقط مالک مجاز است.", show_alert=True)
    _, act, t = c.data.split(":"); uid = int(t)
    if staff(uid) or not q("SELECT 1 FROM access WHERE user_id=?", (uid,)): return await c.answer("کاربر نامعتبر است.", show_alert=True)
    if status_of(uid) not in ("pending", "new"): return await c.answer("این درخواست قبلاً بررسی شده است.", show_alert=True)
    st = {"ok": "approved", "no": "denied", "ban": "banned"}[act]; run("UPDATE access SET status=? WHERE user_id=?", (st, uid)); audit(me.id, st, uid); JC.pop(uid, None)
    label = {"approved": "✅ تأیید شد", "denied": "❌ رد شد", "banned": "⛔️ مسدود شد"}[st]
    for n in q("SELECT chat_id,message_id FROM notif WHERE user_id=?", (uid,)):
        try: await bot.edit_message_text(f"{label} توسط {FA[role(me.id)]}\nکاربر: <code>{uid}</code>", chat_id=n["chat_id"], message_id=n["message_id"])
        except Exception: pass
    if st == "approved":
        for r in q("SELECT inviter_id FROM referrals WHERE invited_id=?", (uid,)):
            if reward(r["inviter_id"]):
                try: await bot.send_message(r["inviter_id"], f"🎉 {S('ref_needed')} دعوت کامل شد؛ {S('ref_days')} روز پلن ویژه فعال شد.")
                except Exception: pass
    try: await bot.send_message(uid, {"approved": "✅ دسترسی شما تأیید شد. /start را بزنید.", "denied": "درخواست دسترسی شما رد شد.", "banned": "⛔️ حساب شما مسدود شد."}[st])
    except Exception: pass
    await c.answer()

@dp.callback_query(F.data.startswith("m:") & ~F.data.in_({"m:ai", "m:buy"}))
async def menus(c: CallbackQuery):
    if not await gate(c): return
    u = c.from_user; uid = u.id; k = c.data[2:]; clear_flow(uid)
    if k == "main": return await home(c, uid, u.first_name or "دوست")
    if k == "profile":
        a = q("SELECT plan,special_until FROM access WHERE user_id=?", (uid,))[0]; until = a["special_until"] or 0
        sp = f"\nاعتبار ویژه: تا {tfmt(until).split()[0]}" if until > time.time() else ""
        return await show(c, f"👤 <b>حساب کاربری</b>\n{HR}\nنام: {html.escape(u.full_name)}\nآیدی: <code>{uid}</code>\nیوزرنیم: {'@' + html.escape(u.username) if u.username else 'ندارد'}\nسطح: <b>{plan_fa(uid, a['plan'])}</b>{sp}\nدعوت موفق: {referral_count(uid)}",
                          [[B(f"📬 گزارش هفتگی: {'روشن ✅' if setting(f'wr:{uid}') == '1' else 'خاموش ⭕️'}", "m:wr")], BACK])
    if k == "wr": set_setting(f"wr:{uid}", "0" if setting(f"wr:{uid}") == "1" else "1"); return await menus(c.model_copy(update={"data": "m:profile"}))
    if k == "ref":
        me = await bot.get_me(); n = referral_count(uid); need = max(1, S("ref_needed"))
        return await show(c, f"🎁 <b>دعوت دوستان</b>\n{HR}\nبا هر <b>{need}</b> دعوت موفق، <b>{S('ref_days')} روز</b> پلن ویژه هدیه می‌گیری.\nدعوت موفق یعنی دوستت وارد ربات شود و مجوزش تأیید شود.\n\nپیشرفت این دور: <b>{n % need}/{need}</b>\nکل دعوت‌های موفق: {n}\n\nلینک اختصاصی تو:\n<code>https://t.me/{me.username}?start=ref_{uid}</code>", [BACK])
    if k == "ch":
        ch = q("SELECT title,username,members FROM channels WHERE owner=? ORDER BY created DESC", (uid,))
        body = "\n".join(f"• <b>{html.escape(x['title'] or '')}</b> — {x['members']} عضو" for x in ch) or "هنوز کانالی ثبت نشده.\nربات را با دسترسی «ارسال پیام» ادمین کانال کنید؛ خودکار اضافه می‌شود."
        return await show(c, "📢 <b>کانال‌های من</b>\n\n" + body, [BACK])
    if k == "queue":
        qs = q("SELECT id,text,run_at FROM posts WHERE owner=? AND status='scheduled' ORDER BY run_at LIMIT 10", (uid,))
        rows = [[B(f"🗑 {time.strftime('%m/%d %H:%M', time.gmtime(x['run_at']))} UTC — {x['text'][:18]}", f"q:{x['id']}")] for x in qs]
        return await show(c, "🕒 <b>صف انتشار</b>\n" + ("برای لغو روی پست بزنید:" if qs else "\nپست زمان‌بندی‌شده‌ای نیست."), rows + [BACK])
    if k == "stats":
        s = {r["status"]: r["n"] for r in q("SELECT status,COUNT(*) n FROM posts WHERE owner=? GROUP BY status", (uid,))}
        return await show(c, f"📊 <b>آمار من</b>\n\nمنتشرشده: {s.get('sent', 0)}\nدر صف: {s.get('scheduled', 0)}\nناموفق: {s.get('failed', 0)}", [BACK])
    if k == "help":
        return await show(c, f"📖 <b>راهنمای کامل</b>\n{HR}\n<b>۱) شروع</b>\nربات را با اجازه‌ی ارسال پیام ادمین کانالت کن؛ کانال خودکار ثبت می‌شود.\n\n<b>۲) ساخت پست</b>\n«✍️ پست جدید» را بزن و متن را بفرست. فرمت‌هایی مثل بولد، ایتالیک و لینک همان‌طور که در تلگرام می‌زنی حفظ می‌شود. عکس و ویدیو با کپشن هم قبول است. زمان‌بندی و دکمه‌ی شیشه‌ای زیر پست در مینی‌اپ است.\n\n<b>۳) هوش مصنوعی 🤖</b>\n• دستی: موضوع و لحن را می‌دهی.\n• هوشمند: سبک کانال را از پست‌هایش می‌فهمد.\n• پست‌های هفته: چند پست یک‌جا می‌نویسد؛ تأیید می‌کنی و سر ساعت منتشر می‌شوند.\n\n<b>۴) مدیریت پست‌ها 📝</b>\nویرایش و حذف پست (از خود کانال هم پاک می‌شود)، و لغو پست‌های صف.\n\n<b>۵) پلن ویژه 💎</b>\nبا خرید (استارز یا کارت‌به‌کارت)، یا با هر {S('ref_needed')} دعوت موفق {S('ref_days')} روز. کد تخفیف و هدیه را هم در همان بخش وارد کن.\n\n<b>۶) پشتیبانی 🆘</b>\nسؤال یا مشکل را همان‌جا بنویس تا پاسخ بگیری.", [[B("🆘 پشتیبانی", "tk:home")], BACK])

@dp.callback_query(F.data.startswith("q:"))
async def qcancel(c: CallbackQuery):
    if not await gate(c): return
    run("DELETE FROM posts WHERE id=? AND owner=? AND status='scheduled'", (int(c.data[2:]), c.from_user.id)); await menus(c.model_copy(update={"data": "m:queue"}))

@dp.callback_query(F.data == "p:new")
async def post_new(c: CallbackQuery):
    if not await gate(c): return
    set_flow(c.from_user.id, s="text"); await show(c, f"✍️ <b>پست جدید</b>\n{HR}\nمتن پست را بفرست؛ فرمت تلگرام (بولد، ایتالیک، لینک) حفظ می‌شود.\nعکس یا ویدیو را هم می‌توانی با کپشن بفرستی.", [[B("❌ انصراف", "m:main")]])
@dp.callback_query(F.data.startswith("p:pub:"))
async def post_pub(c: CallbackQuery):
    if not await gate(c): return
    uid = c.from_user.id; f = get_flow(uid); cid = int(c.data[6:])
    if not (f.get("text") or f.get("media")) or not q("SELECT 1 FROM channels WHERE chat_id=? AND owner=?", (cid, uid)): return await c.answer("منقضی شد؛ دوباره شروع کنید.", show_alert=True)
    if await abuse(uid): return await c.answer("به‌دلیل ارسال بیش‌ازحد، موقتاً محدود شده‌اید.", show_alert=True)
    if used_today(uid) + 1 > cap(uid): return await c.answer(f"سقف ارسال روزانه ({cap(uid)} پست) پر شده است.", show_alert=True)
    pid = add_post(uid, cid, f.get("text", ""), "sending", None, f.get("media"), f.get("mtype"))
    ok = await publish(pid); clear_flow(uid)
    await show(c, "✅ پست منتشر شد." if ok else "❌ انتشار انجام نشد؛ دسترسی ربات را بررسی کنید.", [BACK])

# ── مدیریت در ربات (فقط مالک) ──
ICON = {"approved": "✅", "pending": "⏳", "new": "🆕", "denied": "❌", "banned": "⛔️", "sent": "✅", "scheduled": "🕒", "failed": "❌", "deleted": "🗑"}
def act_text(items):
    return "\n\n".join(f"{ICON.get(x['status'], '•')} <b>{html.escape(x['name'])}</b> ← {html.escape(x['channel'])}\n{html.escape(plain(x['text'])[:70])}\n<i>{ago_fa(x['t'])}</i>" for x in items) or "موردی ثبت نشده."
@dp.callback_query(F.data.startswith("o:"))
async def owner_act(c: CallbackQuery):
    if not owner(c.from_user.id): return await c.answer("دسترسی ندارید.", show_alert=True)
    _, act, t = c.data.split(":"); t = int(t)
    if act == "ban": await user_action(c.from_user.id, t, "ban")
    elif act == "free": run("DELETE FROM settings WHERE key=?", (f"rs:{t}",))
    elif act == "del": await delete_post(t); audit(c.from_user.id, "delete_post", t)
    await c.answer("انجام شد ✅")
@dp.callback_query(F.data.startswith("a:"))
async def admin(c: CallbackQuery):
    uid = c.from_user.id
    if not owner(uid): return await c.answer("دسترسی ندارید.", show_alert=True)
    k = c.data[2:]; clear_flow(uid); go = lambda d: admin(c.model_copy(update={"data": d}))
    if k in ("nt", "rp"):
        key = "notify" if k == "nt" else "report"; set_setting(key, "0" if setting(key) == "1" else "1"); return await go("a:home")
    if k == "home":
        pend = q("SELECT COUNT(*) n FROM access WHERE status='pending'")[0]["n"]; tot = q("SELECT COUNT(*) n FROM access")[0]["n"]
        on = lambda key: "روشن ✅" if setting(key) == "1" else "خاموش ⭕️"; tk = q("SELECT COUNT(*) n FROM tickets WHERE status='open'")[0]["n"]
        rows = [[B(f"📥 درخواست‌های مجوز ({pend})", "a:pend")], pair(B("👥 کاربران", "a:users:0"), B("🕵️ فعالیت کاربران", "a:act")), pair(B(f"🎫 تیکت‌ها ({tk})", "tk:list"), B("🎟 کدها", "cd:list")),
                pair(B("📣 پیام همگانی", "a:bc"), B("🔒 جوین اجباری", "a:fj")), [B("⚙️ تنظیمات فروش و هوش مصنوعی", "s:list")],
                pair(B(f"🔔 اعلان پست: {on('notify')}", "a:nt"), B(f"🌙 گزارش: {on('report')}", "a:rp")), [B("🛠 مدیریت کامل در مینی‌اپ", app=URL)], BACK]
        return await show(c, f"🛡 <b>پنل مدیریت</b>\n{HR}\nکاربران: {tot}\nدرخواست در انتظار: {pend}\nتیکت باز: {tk}", rows)
    if k == "pend":
        rs = q("SELECT user_id,first_name FROM access WHERE status='pending' ORDER BY last_req LIMIT 10")
        rows = [pair(B(f"✅ {r['first_name'] or r['user_id']}", f"d:ok:{r['user_id']}"), B("❌ رد", f"d:no:{r['user_id']}")) for r in rs]
        return await show(c, "📥 <b>درخواست‌های در انتظار</b>" + ("" if rs else "\n\nمورد جدیدی نیست."), rows + [[B("🔙 مدیریت", "a:home")]])
    if k.startswith("users:"):
        pg = int(k[6:]); rs = q("SELECT user_id,first_name,status FROM access WHERE user_id!=? ORDER BY created DESC LIMIT 8 OFFSET ?", (OWNER_ID, pg * 8))
        tot = q("SELECT COUNT(*) n FROM access")[0]["n"]; nav = []
        if pg: nav.append(B("➡️ قبلی", f"a:users:{pg - 1}"))
        if (pg + 1) * 8 < tot: nav.append(B("بعدی ⬅️", f"a:users:{pg + 1}"))
        return await show(c, f"👥 <b>کاربران</b> ({tot})", [[B(f"{ICON.get(r['status'], '')} {r['first_name'] or r['user_id']}", f"a:u:{r['user_id']}")] for r in rs] + ([nav] if nav else []) + [[B("🔙 مدیریت", "a:home")]])
    if k.startswith("x:"):
        _, act, t = k.split(":"); err = await user_action(uid, int(t), act)
        if err: return await c.answer(err, show_alert=True)
        return await go(f"a:u:{t}")
    if k.startswith("u:"):
        t = int(k[2:]); a = q("SELECT * FROM access WHERE user_id=?", (t,))
        if not a: return await c.answer("کاربر پیدا نشد.", show_alert=True)
        a = a[0]; cn = {r["status"]: r["n"] for r in q("SELECT status,COUNT(*) n FROM posts WHERE owner=? GROUP BY status", (t,))}
        nch = q("SELECT COUNT(*) n FROM channels WHERE owner=?", (t,))[0]["n"]
        txt = (f"👤 <b>{html.escape(a['first_name'] or '')}</b>\nآیدی: <code>{t}</code>\nیوزرنیم: {'@' + a['username'] if a['username'] else 'ندارد'}\nوضعیت: {ICON.get(a['status'], '')} {a['status']}\nپلن: {plan_fa(t, a['plan'])}\n"
               f"کانال‌ها: {nch}\nپست منتشرشده: {cn.get('sent', 0)} • در صف: {cn.get('scheduled', 0)} • ناموفق: {cn.get('failed', 0)}\nدعوت موفق: {referral_count(t)}\nامروز: {used_today(t)}/{cap(t)}")
        rows = [pair(B("✅ تأیید", f"a:x:approve:{t}"), B("❌ رد", f"a:x:deny:{t}")),
                [B("♻️ رفع مسدودی", f"a:x:unban:{t}") if a["status"] == "banned" else B("⛔️ مسدود", f"a:x:ban:{t}")],
                [B("⭐️ حذف پلن ویژه", f"a:x:free:{t}") if a["plan"] == "special" else B("⭐️ ارتقا به ویژه", f"a:x:special:{t}")], [B("📝 فعالیت‌ها", f"a:ua:{t}")], [B("🔙 کاربران", "a:users:0")]]
        return await show(c, txt, rows)
    if k == "act":
        it = activity(None, 10); rows = [pair(B(f"🗑 حذف #{x['id']}", f"o:del:{x['id']}"), B(f"⛔️ {x['name'][:10]}", f"o:ban:{x['owner']}")) for x in it[:5] if x["owner"] != OWNER_ID and x["can_delete"]]
        return await show(c, "🕵️ <b>آخرین فعالیت‌ها</b>\n\n" + act_text(it), rows + [[B("🔙 مدیریت", "a:home")]])
    if k.startswith("ua:"):
        t = int(k[3:]); return await show(c, "📝 <b>فعالیت کاربر</b>\n\n" + act_text(activity(t, 8)), [[B("🔙 کاربر", f"a:u:{t}")]])
    if k == "bc":
        set_flow(uid, s="bc"); return await show(c, "📣 متن پیام همگانی را بفرستید:", [[B("❌ انصراف", "a:home")]])
    if k == "bcgo":
        f = get_flow(uid); clear_flow(uid)
        if f.get("text"): audit(uid, "broadcast", f["text"][:40]); asyncio.create_task(broadcast(f["text"], uid))
        return await show(c, "⏳ ارسال شروع شد؛ پس از پایان گزارش می‌گیرید.", [[B("🔙 مدیریت", "a:home")]])
    if k == "fj":
        fs = q("SELECT chat_id,title FROM force_channels")
        rows = [[B(f"🗑 {f['title']}", f"a:fjd:{f['chat_id']}")] for f in fs] + [[B("➕ افزودن کانال", "a:fja")], [B("🔙 مدیریت", "a:home")]]
        return await show(c, "🔒 <b>جوین اجباری</b>" + ("" if fs else "\n\nکانالی تنظیم نشده."), rows)
    if k == "fja":
        set_flow(uid, s="fj"); return await show(c, "یوزرنیم کانال (مثل @channel) را بفرستید یا یک پیام از آن فوروارد کنید.\nربات باید در آن ادمین باشد.", [[B("❌ انصراف", "a:fj")]])
    if k.startswith("fjd:"):
        run("DELETE FROM force_channels WHERE chat_id=?", (int(k[4:]),)); JC.clear(); audit(uid, "force_remove", k[4:]); return await go("a:fj")

# ══ هوش مصنوعی، پلن ویژه، پرداخت، تنظیمات ══
SET = {"ref_needed": ("تعداد دعوت لازم در هر دور", 5, "int"), "ref_days": ("روز ویژه برای هر دور دعوت", 7, "int"), "special_days": ("مدت اشتراک ویژه خریداری‌شده (روز)", 30, "int"),
       "price_stars": ("قیمت اشتراک (استارز)", 250, "int"), "price_card": ("قیمت کارت‌به‌کارت (تومان)", "199000", "str"),
       "card_number": ("شماره کارت", "", "str"), "card_holder": ("نام صاحب کارت", "", "str"),
       "ai_trial": ("تعداد تست رایگان هوش مصنوعی", 3, "int"), "quota_special": ("سقف پست هوش مصنوعی در روز (ویژه)", 10, "int"),
       "ai_channels_special": ("تعداد کانال هوشمند (ویژه)", 2, "int"), "cap_free": ("سقف پست روزانه کاربر عادی", 20, "int"),
       "cap_special": ("سقف پست روزانه ویژه", 100, "int"), "ai_enabled": ("هوش مصنوعی فعال (1 یا 0)", 1, "int"), "buy_enabled": ("خرید فعال (1 یا 0)", 1, "int")}
def S(k):
    v = setting(k, str(SET[k][1]))
    if SET[k][2] == "int": return int(v) if v.lstrip("-").isdigit() else SET[k][1]
    return v
def set_cfg(k, v):
    if k not in SET: return "کلید نامعتبر است"
    v = str(v).strip()
    if SET[k][2] == "int" and not (v.isdigit() and int(v) <= 10**9): return "فقط عدد صحیح وارد کنید"
    if len(v) > 100: return "مقدار خیلی طولانی است"
    set_setting(k, v); return None
def is_special(uid):
    r = q("SELECT plan,special_until FROM access WHERE user_id=?", (uid,))
    return bool(r and (r[0][0] == "special" or (r[0][1] or 0) > time.time()))
def grant_special(uid, days):
    r = q("SELECT special_until FROM access WHERE user_id=?", (uid,)); base = max(time.time(), (r[0][0] or 0) if r else 0)
    run("UPDATE access SET special_until=? WHERE user_id=?", (int(base + days * 86400), uid))
def trial_left(uid): return max(0, S("ai_trial") - int(setting(f"trial:{uid}", "0")))
def ai_today(uid): return q("SELECT COUNT(*) n FROM ai_log WHERE user_id=? AND ts>?", (uid, int(time.time()) - 86400))[0]["n"]
def premium(uid): return is_special(uid) or role(uid) == "admin"
def can_ai(uid):
    if owner(uid): return True, ""
    if S("ai_enabled") != 1: return False, "off"
    if premium(uid): return (ai_today(uid) < S("quota_special")), "quota"
    return trial_left(uid) > 0, "locked"
def ai_use(uid):
    run("INSERT INTO ai_log VALUES(?,?)", (uid, int(time.time())))
    if not owner(uid) and not premium(uid): set_setting(f"trial:{uid}", int(setting(f"trial:{uid}", "0")) + 1)
def max_ai_channels(uid): return 99 if owner(uid) else S("ai_channels_special") if premium(uid) else 1
PROV = [("gemini", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", os.getenv("GEMINI_API_KEY", ""), os.getenv("GEMINI_MODEL", "gemini-2.5-flash")),
        ("groq", "https://api.groq.com/openai/v1/chat/completions", os.getenv("GROQ_API_KEY", ""), os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")),
        ("openrouter", "https://openrouter.ai/api/v1/chat/completions", os.getenv("OPENROUTER_API_KEY", ""), os.getenv("OPENROUTER_MODEL", "google/gemma-4-31b-it:free"))]
async def ai_chat(system, user, max_tokens=700):
    for name, url, key, model in PROV:
        if not key: continue
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=45)) as ss:
                async with ss.post(url, headers={"Authorization": f"Bearer {key}"}, json={"model": model, "max_tokens": max_tokens, "temperature": 0.8,
                        "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}) as r:
                    if r.status != 200: log.warning("ai %s status %s", name, r.status); continue
                    t = ((await r.json())["choices"][0]["message"]["content"] or "").strip()
                    if t: return t
        except Exception: log.exception("ai %s", name)
    raise RuntimeError("no_ai")
TONES = ["دوستانه", "رسمی", "خبری", "انگیزشی", "طنز"]; PRESETS = {1: [20], 2: [12, 20], 3: [10, 15, 20], 5: [9, 12, 15, 18, 21], 10: [8, 9, 10, 11, 12, 14, 16, 18, 20, 21]}
ERR = {"locked": "🔒 تست رایگان شما تمام شده؛ برای ادامه به پلن ویژه ارتقا دهید.", "quota": "سهمیه‌ی امروز تمام شد؛ فردا دوباره امتحان کنید.", "off": "هوش مصنوعی موقتاً غیرفعال است.",
       "need_topic": "ابتدا موضوع کانال را تنظیم کنید.", "need_samples": "برای حالت هوشمند حداقل ۳ پست نمونه لازم است. نمونه ارسال کنید یا صبر کنید ربات پست‌های جدید کانال را ببیند.",
       "fail": "سرویس هوش مصنوعی موقتاً در دسترس نیست؛ کمی بعد تلاش کنید."}
def ensure_cfg(cid, uid):
    run("INSERT OR IGNORE INTO ai_cfg(chat_id,owner,mode,topic,tone,publish,enabled,times,per_day,profile,profile_at,last_slot) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", (cid, uid, "manual", "", "دوستانه", "draft", 0, "[20]", 1, "", 0, ""))
    return q("SELECT * FROM ai_cfg WHERE chat_id=?", (cid,))[0]
def norm_handle(t):
    t = (t or "").strip()
    if t == "-": return ""
    t = re.sub(r"^https?://t\.me/", "@", t)
    if re.fullmatch(r"@?\w{4,32}", t): return t if t.startswith("@") else "@" + t
    return None
def sig_text(c):
    p = ([f"📩 پشتیبانی: {c['support']}"] if c["support"] else []) + ([f"📢 کانال: {c['chan']}"] if c["chan"] else []) + ([c["sig"]] if c["sig"] else [])
    return "\n".join(p)
async def analyze(cid):
    smp = [r["text"][:400] for r in q("SELECT text FROM ai_samples WHERE chat_id=? ORDER BY id DESC LIMIT 15", (cid,))]
    if len(smp) < 3: raise ValueError("need_samples")
    prof = await ai_chat("تحلیلگر محتوای کانال‌های تلگرام هستی. فقط فارسی و حداکثر ۶ خط پاسخ بده.", "پست‌های یک کانال:\n\n" + "\n---\n".join(smp) + "\n\nموضوع اصلی، مخاطب، لحن، سبک نوشتار و ساختار پست‌ها (طول، ایموجی، هشتگ) را توصیف کن.", 500)
    run("UPDATE ai_cfg SET profile=?, profile_at=? WHERE chat_id=?", (prof[:1500], int(time.time()), cid)); return prof
async def gen_text(c):
    cid = c["chat_id"]; recent = [r["text"][:90] for r in q("SELECT text FROM drafts WHERE chat_id=? AND status!='rejected' ORDER BY id DESC LIMIT 6", (cid,))]
    if c["mode"] == "smart":
        prof = c["profile"] if c["profile"] and time.time() - c["profile_at"] < 3 * 86400 else await analyze(cid)
        smp = [r["text"][:300] for r in q("SELECT text FROM ai_samples WHERE chat_id=? ORDER BY id DESC LIMIT 4", (cid,))]
        brief = f"مشخصات کانال:\n{prof}\n\nنمونه‌ی پست‌های واقعی کانال:\n" + "\n---\n".join(smp)
    else:
        if not c["topic"]: raise ValueError("need_topic")
        brief = f"موضوع کانال: {c['topic']}\nلحن: {c['tone']}"
    sys_ = "تو نویسنده‌ی حرفه‌ای کانال تلگرام هستی. فقط متن نهایی یک پست را به فارسی بنویس، بدون مقدمه و توضیح اضافه. حداکثر ۷۰۰ کاراکتر. فقط از **ضخیم** و __کج__ و ایموجی مناسب استفاده کن. محتوا مفید و جذاب باشد و آمار یا ادعای ساختگی نداشته باشد. قوانین سخت: هرگز جای‌خالی مثل [آیدی] یا {نام} ننویس؛ هیچ آیدی، یوزرنیم، لینک یا شماره تلفن نساز؛ به «پیام بده» یا «تماس بگیر» اشاره نکن (امضای کانال را سیستم خودش اضافه می‌کند)."
    usr = brief + ("\n\nپست‌های اخیر (تکرار نکن):\n- " + "\n- ".join(recent) if recent else "") + "\n\nیک پست جدید و متفاوت بنویس."
    t = re.sub(r"^```\w*\n?|```$", "", (await ai_chat(sys_, usr)).strip()).strip()
    t, n1 = re.subn(r"\[[^\]]*\]|\{[^}]*\}", "", t); t, n2 = re.subn(r"https?://\S+|t\.me/\S+|(?<![\w@])@\w{3,}", "", t)
    t = re.sub(r"[ \t]{2,}", " ", t).strip()[:3300]; flag = bool(n1 + n2)
    n = q("SELECT COUNT(*) n FROM drafts WHERE chat_id=? AND status!='rejected'", (cid,))[0]["n"]
    t = render_text(t)
    if sig_text(c) and n % max(1, c["sig_every"]) == 0: t += "\n\n" + html.escape(sig_text(c), quote=False)
    return t, flag
async def publish_draft(did, uid):
    d = q("SELECT * FROM drafts WHERE id=? AND owner=? AND status='draft'", (did, uid))
    if not d or not q("SELECT 1 FROM channels WHERE chat_id=? AND owner=?", (d[0]["chat_id"], uid)): return False
    pid = add_post(uid, d[0]["chat_id"], d[0]["text"], "sending")
    ok = await publish(pid)
    if ok: run("UPDATE drafts SET status='published' WHERE id=?", (did,))
    return ok
def draft_msg(did):
    d = q("SELECT d.text,c.title FROM drafts d LEFT JOIN channels c ON c.chat_id=d.chat_id WHERE d.id=?", (did,))[0]
    return f"🤖 <b>پیش‌نویس هوش مصنوعی</b> — {html.escape(d['title'] or '')}\n\n{d['text']}", Kb(inline_keyboard=[
        pair(B("✅ انتشار", f"ai:pub:{did}"), B("🔄 بازنویسی", f"ai:re:{did}")), pair(B("✏️ ویرایش", f"ai:ed:{did}"), B("🗑 حذف", f"ai:del:{did}"))])
async def ai_make(uid, cid, notify=True):
    ok, why = can_ai(uid)
    if not ok: return why
    c = ensure_cfg(cid, uid)
    try: t, flag = await gen_text(c)
    except ValueError as e: return str(e)
    except Exception: return "fail"
    ai_use(uid); did = run("INSERT INTO drafts(owner,chat_id,text,status,created) VALUES(?,?,?,?,?)", (uid, cid, t, "draft", int(time.time()))).lastrowid
    if notify:
        try:
            if c["publish"] == "auto" and not flag:
                done = await publish_draft(did, uid); await bot.send_message(uid, "🤖 پست هوشمند منتشر شد ✅" if done else "🤖 انتشار پست هوشمند انجام نشد؛ دسترسی ربات را بررسی کنید.")
            else:
                txt, kb = draft_msg(did); await bot.send_message(uid, txt, reply_markup=kb)
        except Exception: pass
    return "ok"
async def ai_loop():
    while True:
        await asyncio.sleep(120)
        try:
            now = time.gmtime(time.time() + 12600); slot = time.strftime("%Y%m%d%H", now)
            for c in q("SELECT * FROM ai_cfg WHERE enabled=1"):
                if now.tm_hour not in json.loads(c["times"] or "[]") or c["last_slot"] == slot or status_of(c["owner"]) != "approved": continue
                run("UPDATE ai_cfg SET last_slot=? WHERE chat_id=?", (slot, c["chat_id"]))
                r = await ai_make(c["owner"], c["chat_id"])
                if r in ("quota", "locked", "off"): run("UPDATE ai_cfg SET enabled=0 WHERE chat_id=?", (c["chat_id"],)); await bot.send_message(c["owner"], "🤖 " + ERR[r] + "\nانتشار هوشمند متوقف شد.")
        except Exception: log.exception("ai_loop")

# ── ربات: هوش مصنوعی ──
async def ai_home(ev):
    uid = ev.from_user.id; ok, _ = can_ai(uid); sp = premium(uid) or owner(uid); ch = q("SELECT chat_id,title FROM channels WHERE owner=?", (uid,))
    st = f"💎 ویژه • امروز {ai_today(uid)}" + ("" if owner(uid) else f"/{S('quota_special')}") if sp else f"رایگان • تست باقی‌مانده: {trial_left(uid)}"
    rows = [[B(("🟢 " if (q('SELECT enabled FROM ai_cfg WHERE chat_id=?', (x['chat_id'],)) or [[0]])[0][0] else "⚪️ ") + (x["title"] or "کانال")[:35], f"ai:c:{x['chat_id']}")] for x in ch]
    if not sp: rows.append([B("💎 ارتقا به پلن ویژه", "m:buy")])
    await show(ev, "🤖 <b>هوش مصنوعی کانال</b>\n\nوضعیت: " + st + "\n\n• <b>دستی:</b> موضوع را می‌دهید و ربات پست می‌نویسد.\n• <b>هوشمند:</b> ربات سبک کانال را می‌فهمد و هم‌سبک می‌نویسد.\n\n" + ("یک کانال را انتخاب کنید:" if ch else "ابتدا ربات را ادمین یک کانال کنید."), rows + [BACK])
async def ai_channel(ev, cid):
    uid = ev.from_user.id
    if not q("SELECT 1 FROM channels WHERE chat_id=? AND owner=?", (cid, uid)): return await show(ev, "کانال پیدا نشد.", [BACK])
    c = ensure_cfg(cid, uid); title = q("SELECT title FROM channels WHERE chat_id=?", (cid,))[0][0]; smart = c["mode"] == "smart"
    n = q("SELECT COUNT(*) n FROM ai_samples WHERE chat_id=?", (cid,))[0]["n"]
    txt = (f"🤖 <b>{html.escape(title or '')}</b>\n{HR}\nوضعیت: {'🟢 فعال' if c['enabled'] else '⚪️ خاموش'}\nحالت: {'🧠 هوشمند' if smart else '✍️ دستی'}\n"
           + (f"نمونه‌های ذخیره‌شده: {n}\n" + (f"تحلیل: {html.escape(c['profile'][:200])}\n" if c['profile'] else "") if smart else f"موضوع: {html.escape(c['topic']) or '—'}\nلحن: {c['tone']}\n")
           + f"پشتیبانی: {html.escape(c['support']) or '—'}\nآیدی کانال: {html.escape(c['chan']) or '—'}\nامضای اضافه: {html.escape(c['sig']) or '—'}\nتعداد در روز: {c['per_day']}\nانتشار: {'⚡️ خودکار' if c['publish'] == 'auto' else '📝 پیش‌نویس برای تأیید'}")
    rows = [[B("⏸ خاموش کردن" if c["enabled"] else "▶️ روشن کردن", f"ai:t:{cid}:en")], pair(B("🧠 حالت هوشمند" if not smart else "✍️ حالت دستی", f"ai:t:{cid}:mode"), B(f"🔢 {c['per_day']} پست در روز", f"ai:t:{cid}:n")),
            [B("⚡️ انتشار خودکار" if c["publish"] != "auto" else "📝 فقط پیش‌نویس", f"ai:t:{cid}:pub")],
            pair(B("🎯 موضوع", f"ai:topic:{cid}"), B(f"🎭 لحن: {c['tone']}", f"ai:t:{cid}:tone")) if not smart else pair(B("📚 ارسال نمونه پست", f"ai:smp:{cid}"), B("🔍 تحلیل کانال", f"ai:an:{cid}")),
            pair(B("📩 آیدی پشتیبانی", f"ai:sp:{cid}"), B("📢 آیدی کانال", f"ai:cn:{cid}")), pair(B("🏷 متن امضا", f"ai:sig:{cid}"), B(f"🔁 امضا هر {c['sig_every']} پست", f"ai:t:{cid}:sg"))]
    await show(ev, txt, rows + [[B("✨ تولید یک پست الان", f"ai:gen:{cid}")], [B("📅 پست‌های هفته (تقویم محتوا)", f"bt:menu:{cid}")], [B("🔙 هوش مصنوعی", "m:ai")]])
@dp.callback_query(F.data.startswith("ai:"))
async def ai_cb(c: CallbackQuery):
    if not await gate(c): return
    uid = c.from_user.id; p = c.data.split(":"); k = p[1]
    if k in ("c", "t", "topic", "smp", "an", "gen", "sig", "sk", "sp", "cn"):
        cid = int(p[2])
        if not q("SELECT 1 FROM channels WHERE chat_id=? AND owner=?", (cid, uid)): return await c.answer("کانال پیدا نشد.", show_alert=True)
        cfg = ensure_cfg(cid, uid)
    if k == "c": clear_flow(uid); return await ai_channel(c, cid)
    if k == "t":
        a = p[3]
        if a == "en":
            if not cfg["enabled"]:
                ok, why = can_ai(uid)
                if not ok: return await c.answer(ERR[why], show_alert=True)
                if q("SELECT COUNT(*) n FROM ai_cfg WHERE owner=? AND enabled=1", (uid,))[0]["n"] >= max_ai_channels(uid): return await c.answer(f"سقف کانال هوشمند شما {max_ai_channels(uid)} است. برای بیشتر، پلن ویژه بگیرید.", show_alert=True)
                if cfg["mode"] == "manual" and not cfg["topic"]: return await c.answer(ERR["need_topic"], show_alert=True)
                if not (cfg["sig"] or cfg["support"] or cfg["chan"]) and not cfg["sig_asked"]:
                    run("UPDATE ai_cfg SET sig_asked=1 WHERE chat_id=?", (cid,)); return await sig_wizard(c, uid, cid)
            run("UPDATE ai_cfg SET enabled=? WHERE chat_id=?", (0 if cfg["enabled"] else 1, cid))
        elif a == "sg": run("UPDATE ai_cfg SET sig_every=? WHERE chat_id=?", ({1: 2, 2: 3, 3: 5}.get(cfg["sig_every"], 1), cid))
        elif a == "mode": run("UPDATE ai_cfg SET mode=? WHERE chat_id=?", ("manual" if cfg["mode"] == "smart" else "smart", cid))
        elif a == "pub": run("UPDATE ai_cfg SET publish=? WHERE chat_id=?", ("draft" if cfg["publish"] == "auto" else "auto", cid))
        elif a == "tone": run("UPDATE ai_cfg SET tone=? WHERE chat_id=?", (TONES[(TONES.index(cfg["tone"]) + 1) % len(TONES)] if cfg["tone"] in TONES else TONES[0], cid))
        elif a == "n":
            lim = 10 if owner(uid) else max(1, S("quota_special")) if premium(uid) else 1; opts = [x for x in PRESETS if x <= lim] or [1]
            nx = next((x for x in opts if x > cfg["per_day"]), opts[0]); run("UPDATE ai_cfg SET per_day=?, times=? WHERE chat_id=?", (nx, json.dumps(PRESETS[nx]), cid))
        return await ai_channel(c, cid)
    if k == "sk":
        if p[3] == "1": set_flow(uid, s="ai_chan", cid=cid, wiz=1); return await show(c, CH_Q, [[B("⏭ نمی‌خواهم", f"ai:sk:{cid}:2")]])
        run("UPDATE ai_cfg SET sig_asked=1 WHERE chat_id=?", (cid,)); clear_flow(uid); return await ai_channel(c, cid)
    if k == "sp": set_flow(uid, s="ai_support", cid=cid); return await show(c, "📩 آیدی پشتیبانی را بفرستید (مثل @support).\nبرای حذف، یک خط تیره (-) بفرستید.", [[B("❌ انصراف", f"ai:c:{cid}")]])
    if k == "cn": set_flow(uid, s="ai_chan", cid=cid); return await show(c, "📢 آیدی کانال را بفرستید (مثل @mychannel).\nبرای حذف، یک خط تیره (-) بفرستید.", [[B("❌ انصراف", f"ai:c:{cid}")]])
    if k == "sig": set_flow(uid, s="ai_sig", cid=cid); return await show(c, "🏷 آیدی تماس یا امضای کانال را بفرستید (حداکثر ۲۰۰ کاراکتر).\nبرای حذف امضا، یک خط تیره (-) بفرستید.", [[B("❌ انصراف", f"ai:c:{cid}")]])
    if k == "topic": set_flow(uid, s="ai_topic", cid=cid); return await show(c, "🎯 موضوع کانال را بفرستید.\nمثال: «اخبار و آموزش برنامه‌نویسی پایتون برای مبتدی‌ها»", [[B("❌ انصراف", f"ai:c:{cid}")]])
    if k == "smp": set_flow(uid, s="ai_samples", cid=cid); return await show(c, "📚 چند پست نمونه از کانال را بفرستید (فوروارد هم قبول است؛ ۵ تا ۱۰ پست عالی است).\nبعد از اتمام دکمه‌ی «پایان» را بزنید.", [[B("✅ پایان", f"ai:c:{cid}")]])
    if k == "an":
        ok, why = can_ai(uid)
        if not ok: return await c.answer(ERR[why], show_alert=True)
        await c.answer("در حال تحلیل…")
        try: await analyze(cid)
        except ValueError: return await c.answer(ERR["need_samples"], show_alert=True)
        except Exception: return await c.answer(ERR["fail"], show_alert=True)
        return await ai_channel(c, cid)
    if k == "gen":
        await c.answer("⏳ در حال نوشتن…"); r = await ai_make(uid, cid, notify=True)
        return await c.answer(ERR[r], show_alert=True) if r != "ok" else None
    did = int(p[2]); d = q("SELECT * FROM drafts WHERE id=? AND owner=? AND status='draft'", (did, uid))
    if not d: return await c.answer("این پیش‌نویس دیگر معتبر نیست.", show_alert=True)
    if k == "pub":
        ok = await publish_draft(did, uid); await c.answer("منتشر شد ✅" if ok else "انتشار ناموفق بود", show_alert=not ok)
        if ok: await c.message.edit_text(c.message.html_text + "\n\n✅ <b>منتشر شد</b>", reply_markup=None)
    elif k == "del":
        run("UPDATE drafts SET status='rejected' WHERE id=?", (did,)); await c.answer("حذف شد")
        try: await c.message.edit_text("🗑 پیش‌نویس حذف شد.")
        except Exception: pass
    elif k == "re":
        ok, why = can_ai(uid)
        if not ok: return await c.answer(ERR[why], show_alert=True)
        await c.answer("⏳ در حال بازنویسی…")
        try: t, _ = await gen_text(ensure_cfg(d[0]["chat_id"], uid))
        except Exception: return await c.answer(ERR["fail"], show_alert=True)
        ai_use(uid); run("UPDATE drafts SET text=? WHERE id=?", (t, did)); txt, kb = draft_msg(did)
        try: await c.message.edit_text(txt, reply_markup=kb)
        except Exception: pass
    elif k == "ed":
        set_flow(uid, s="ai_edit", did=did); await c.message.answer("✏️ متن جدید پست را بفرستید:"); await c.answer()
SP_Q = "📩 <b>آیدی پشتیبانی</b> کانالت چیست؟\nمثال: @support\nاگر بدهی، ربات زیر پست‌ها می‌نویسد «پشتیبانی: …». اگر نمی‌خواهی، رد کن؛ هوش مصنوعی چیزی اضافه نمی‌کند."
CH_Q = "📢 <b>آیدی کانال</b> را بفرست تا زیر پست‌ها بیاید؟\nمثال: @mychannel\nاگر نمی‌خواهی، رد کن."
async def sig_wizard(ev, uid, cid):
    set_flow(uid, s="ai_support", cid=cid, wiz=1); await show(ev, SP_Q, [[B("⏭ نمی‌خواهم", f"ai:sk:{cid}:1")]])
AI_FLOWS = {"bt_edit", "tk_new", "tk_user", "tk_reply", "code", "code_new", "mp_edit", "ai_support", "ai_chan", "ai_topic", "ai_samples", "ai_edit", "ai_sig", "rcpt", "set"}
async def ai_flow(m: Message, f):
    uid = m.from_user.id; s = f["s"]
    if s == "bt_edit":
        t = clean_html(m.html_text or "") if m.text else ""
        if not plain(t).strip() or len(plain(t)) > MAX_LEN: return await m.answer("متن نامعتبر است.")
        d = q("SELECT chat_id FROM drafts WHERE id=? AND owner=? AND status='batch'", (f["did"], uid)); clear_flow(uid)
        if d: run("UPDATE drafts SET text=? WHERE id=?", (t, f["did"])); return await m.answer("✅ ویرایش شد.", reply_markup=Kb(inline_keyboard=[[B("👁 پست‌های هفته", f"bt:l:{d[0]['chat_id']}")]]))
        return
    if s == "tk_new":
        if not await gate(m): return
        t = (m.text or "").strip()
        if not t or len(t) > 1000: return await m.answer("پیام باید متن و حداکثر ۱۰۰۰ کاراکتر باشد.")
        tid = run("INSERT INTO tickets(user_id,status,created,last_at) VALUES(?,?,?,?)", (uid, "open", int(time.time()), int(time.time()))).lastrowid
        run("INSERT INTO ticket_msgs(ticket_id,from_owner,text,created) VALUES(?,?,?,?)", (tid, 0, t, int(time.time()))); clear_flow(uid); await tk_forward(tid, uid, m.from_user.full_name, t)
        return await show(m, f"✅ پیام شما ثبت شد (تیکت #{tid}). پاسخ را همین‌جا می‌گیرید.", [BACK])
    if s == "tk_user":
        t = (m.text or "").strip(); tk = q("SELECT id FROM tickets WHERE id=? AND user_id=? AND status='open'", (f["id"], uid))
        if not tk or not t or len(t) > 1000: clear_flow(uid); return await m.answer("پیام نامعتبر است یا تیکت بسته شده است.")
        run("INSERT INTO ticket_msgs(ticket_id,from_owner,text,created) VALUES(?,?,?,?)", (f["id"], 0, t, int(time.time()))); run("UPDATE tickets SET last_at=? WHERE id=?", (int(time.time()), f["id"]))
        clear_flow(uid); await tk_forward(f["id"], uid, m.from_user.full_name, t); return await show(m, "✅ پیام شما ارسال شد.", [BACK])
    if s == "tk_reply":
        if not owner(uid): return
        t = clean_html(m.html_text or "") if m.text else ""; tk = q("SELECT user_id FROM tickets WHERE id=?", (f["id"],))
        if not tk or not plain(t).strip(): return await m.answer("پیام نامعتبر است.")
        run("INSERT INTO ticket_msgs(ticket_id,from_owner,text,created) VALUES(?,?,?,?)", (f["id"], 1, plain(t), int(time.time()))); run("UPDATE tickets SET last_at=? WHERE id=?", (int(time.time()), f["id"])); clear_flow(uid)
        try: await bot.send_message(tk[0]["user_id"], f"💬 <b>پاسخ پشتیبانی</b> — تیکت #{f['id']}\n{HR}\n{t}", reply_markup=Kb(inline_keyboard=[[B("✉️ پاسخ دادن", f"tk:u:{f['id']}")]]))
        except Exception: return await m.answer("⚠️ ارسال به کاربر ممکن نشد (احتمالاً ربات را بلاک کرده).")
        return await m.answer("✅ پاسخ ارسال شد.", reply_markup=Kb(inline_keyboard=[[B("🎫 تیکت‌ها", "tk:list")]]))
    if s == "code":
        if not await gate(m): return
        code = (m.text or "").strip().upper(); r = q("SELECT * FROM codes WHERE code=?", (code,)); clear_flow(uid)
        if not r or r[0]["used"] >= r[0]["max_uses"]: return await m.answer("❌ کد نامعتبر یا تمام‌شده است.")
        if q("SELECT 1 FROM code_uses WHERE code=? AND user_id=?", (code, uid)): return await m.answer("شما قبلاً از این کد استفاده کرده‌اید.")
        if r[0]["kind"] == "g":
            grant_special(uid, r[0]["value"]); run("INSERT INTO code_uses VALUES(?,?)", (code, uid)); run("UPDATE codes SET used=used+1 WHERE code=?", (code,))
            return await show(m, f"🎁 {r[0]['value']} روز پلن ویژه برای شما فعال شد.", [[B("🤖 هوش مصنوعی", "m:ai")]])
        set_setting(f"disc:{uid}", f"{code}:{r[0]['value']}"); return await show(m, f"✅ {r[0]['value']}٪ تخفیف اعمال شد؛ هنگام پرداخت لحاظ می‌شود.", [[B("💎 پلن ویژه", "m:buy")]])
    if s == "code_new":
        if not owner(uid): return
        p = (m.text or "").split()
        try: code, kind, val, mx = p[0].upper(), p[1].lower(), int(p[2]), int(p[3])
        except Exception: return await m.answer("قالب نامعتبر است. مثال: OFF30 d 30 10")
        if not re.fullmatch(r"[A-Z0-9_]{3,20}", code) or kind not in ("d", "g") or not (1 <= val <= (100 if kind == "d" else 365)) or not (1 <= mx <= 100000): return await m.answer("مقادیر نامعتبر است.")
        run("INSERT OR REPLACE INTO codes(code,kind,value,max_uses,used,created) VALUES(?,?,?,?,0,?)", (code, kind, val, mx, int(time.time()))); audit(uid, "code_new", code); clear_flow(uid)
        return await show(m, f"✅ کد <code>{code}</code> ساخته شد.", [[B("🎟 کدها", "cd:list")]])
    if s == "set":
        if not owner(uid): return
        key = list(SET)[f["i"]]; err = set_cfg(key, (m.text or "").strip() if m.text else "x" * 999)
        if err: return await m.answer("❌ " + err)
        clear_flow(uid); audit(uid, "set_" + key, ""); return await show(m, "✅ ذخیره شد.", [[B("⚙️ تنظیمات", "s:list")]])
    if s == "rcpt":
        if not m.photo: return await m.answer("لطفاً عکس رسید پرداخت را بفرستید.")
        clear_flow(uid); pid = run("INSERT INTO payments(user_id,method,amount,status,created,file_id) VALUES(?,?,?,?,?,?)", (uid, "card", card_price(uid), "pending", int(time.time()), m.photo[-1].file_id)).lastrowid
        try: await bot.send_photo(OWNER_ID, m.photo[-1].file_id, caption=f"💳 <b>رسید کارت‌به‌کارت</b>\nکاربر: {html.escape(m.from_user.full_name)} • <code>{uid}</code>\nمبلغ: {card_price(uid):,} تومان",
                                 reply_markup=Kb(inline_keyboard=[pair(B("✅ تأیید", f"pay:ok:{pid}"), B("❌ رد", f"pay:no:{pid}"))]))
        except Exception: pass
        return await show(m, "✅ رسید ارسال شد. پس از بررسی مدیریت، نتیجه اعلام می‌شود.", [BACK])
    cid = f.get("cid")
    if s == "ai_topic":
        if not m.text or len(m.text) > 300: return await m.answer("موضوع باید متن و حداکثر ۳۰۰ کاراکتر باشد.")
        run("UPDATE ai_cfg SET topic=? WHERE chat_id=? AND owner=?", (m.text.strip(), cid, uid)); clear_flow(uid); cf = ensure_cfg(cid, uid)
        if not (cf["sig"] or cf["support"] or cf["chan"]) and not cf["sig_asked"]: return await sig_wizard(m, uid, cid)
        return await ai_channel(m, cid)
    if s in ("ai_support", "ai_chan"):
        h = norm_handle(m.text)
        if h is None: return await m.answer("آیدی نامعتبر است؛ مثل @name بفرستید (یا - برای حذف).")
        run(f"UPDATE ai_cfg SET {'support' if s == 'ai_support' else 'chan'}=? WHERE chat_id=? AND owner=?", (h, cid, uid))
        if f.get("wiz") and s == "ai_support": set_flow(uid, s="ai_chan", cid=cid, wiz=1); return await show(m, CH_Q, [[B("⏭ نمی‌خواهم", f"ai:sk:{cid}:2")]])
        run("UPDATE ai_cfg SET sig_asked=1 WHERE chat_id=?", (cid,)); clear_flow(uid); return await ai_channel(m, cid)
    if s == "ai_sig":
        t = (m.text or "").strip()
        if not t or len(t) > 200: return await m.answer("متن امضا باید حداکثر ۲۰۰ کاراکتر باشد. برای حذف، یک خط تیره (-) بفرستید.")
        run("UPDATE ai_cfg SET sig=?, sig_asked=1 WHERE chat_id=? AND owner=?", ("" if t == "-" else t, cid, uid)); clear_flow(uid); return await ai_channel(m, cid)
    if s == "ai_samples":
        t = m.text or m.caption or ""
        if len(t) < 20: return await m.answer("متن نمونه باید حداقل ۲۰ کاراکتر باشد.")
        run("INSERT INTO ai_samples(chat_id,text,created) VALUES(?,?,?)", (cid, t[:1500], int(time.time())))
        run("DELETE FROM ai_samples WHERE chat_id=? AND id NOT IN (SELECT id FROM ai_samples WHERE chat_id=? ORDER BY id DESC LIMIT 60)", (cid, cid))
        return await m.answer(f"✅ ثبت شد ({q('SELECT COUNT(*) n FROM ai_samples WHERE chat_id=?', (cid,))[0]['n']} نمونه). ادامه دهید یا «پایان» را بزنید.")
    if s == "ai_edit":
        t = clean_html(m.html_text or "") if m.text else ""
        if not plain(t).strip() or len(plain(t)) > 4000: return await m.answer("متن نامعتبر است.")
        run("UPDATE drafts SET text=? WHERE id=? AND owner=? AND status='draft'", (t, f["did"], uid)); clear_flow(uid); txt, kb = draft_msg(f["did"]); await m.answer(txt, reply_markup=kb)
    if s == "mp_edit":
        t = clean_html(m.html_text or "") if (m.text or m.caption) else ""; err = await user_edit(uid, f["id"], t); clear_flow(uid)
        await m.answer("✅ ویرایش شد." if not err else "❌ " + err, reply_markup=Kb(inline_keyboard=[[B("📝 پست‌های من", "mp:list")]]))
@dp.channel_post(F.text)
async def on_ch_post(m: Message):
    if len(m.text) >= 30 and q("SELECT 1 FROM channels WHERE chat_id=?", (m.chat.id,)):
        run("INSERT INTO ai_samples(chat_id,text,created) VALUES(?,?,?)", (m.chat.id, m.text[:1500], int(time.time())))
        run("DELETE FROM ai_samples WHERE chat_id=? AND id NOT IN (SELECT id FROM ai_samples WHERE chat_id=? ORDER BY id DESC LIMIT 60)", (m.chat.id, m.chat.id))

# ── ربات: پلن ویژه و پرداخت ──
async def buy_menu(ev):
    uid = ev.from_user.id; r = q("SELECT special_until,plan FROM access WHERE user_id=?", (uid,)); until = (r[0][0] or 0) if r else 0
    cur = "\n\n✅ اشتراک ویژه شما فعال است" + (f" تا {time.strftime('%Y/%m/%d', time.gmtime(until))}" if until > time.time() else " (دائمی)") if is_special(uid) else ""
    txt = (f"💎 <b>پلن ویژه</b>\n\n🤖 هوش مصنوعی: {S('quota_special')} پست در روز\n🧠 {S('ai_channels_special')} کانال هوشمند\n📤 سقف ارسال: {S('cap_special')} پست در روز\n\n"
           f"قیمت ({S('special_days')} روز):\n⭐️ {stars_price(uid)} استارز  یا  💳 {card_price(uid):,} تومان{(' (تخفیف ' + str(disc(uid)) + '٪ اعمال شد 🎟)') if disc(uid) else ''}\n🎁 یا با هر {S('ref_needed')} دعوت، {S('ref_days')} روز رایگان" + cur)
    rows = [[B("⭐️ پرداخت با استارز", "pay:stars")], [B("💳 کارت‌به‌کارت", "pay:card")], [B("🎟 کد تخفیف / هدیه", "cd:enter")]] if S("buy_enabled") == 1 else [[B("🎟 کد تخفیف / هدیه", "cd:enter")]]
    await show(ev, txt, rows + [[B("🎁 دعوت دوستان (رایگان)", "m:ref")], BACK])
@dp.callback_query(F.data.in_({"m:ai", "m:buy"}))
async def ai_buy_entry(c: CallbackQuery):
    if not await gate(c): return
    clear_flow(c.from_user.id); await (ai_home(c) if c.data == "m:ai" else buy_menu(c))
@dp.callback_query(F.data.startswith("pay:"))
async def pay_cb(c: CallbackQuery):
    uid = c.from_user.id; k = c.data[4:].split(":"); a = k[0]
    if a in ("ok", "no"):
        if not owner(uid): return await c.answer("فقط مالک.", show_alert=True)
        p = q("SELECT * FROM payments WHERE id=? AND status='pending'", (int(k[1]),))
        if not p: return await c.answer("قبلاً بررسی شده است.", show_alert=True)
        p = p[0]; run("UPDATE payments SET status=? WHERE id=?", ("paid" if a == "ok" else "rejected", p["id"])); audit(uid, "pay_" + a, p["user_id"])
        if a == "ok": grant_special(p["user_id"], S("special_days")); consume_disc(p["user_id"])
        try: await bot.send_message(p["user_id"], f"✅ پرداخت شما تأیید شد؛ پلن ویژه {S('special_days')} روزه فعال شد." if a == "ok" else "❌ رسید شما تأیید نشد. در صورت اشتباه، با پشتیبانی تماس بگیرید.")
        except Exception: pass
        try: await c.message.edit_caption(caption=(c.message.caption or "") + ("\n\n✅ تأیید شد" if a == "ok" else "\n\n❌ رد شد"), reply_markup=None)
        except Exception: pass
        return await c.answer("انجام شد")
    if not await gate(c): return
    if S("buy_enabled") != 1: return await c.answer("خرید موقتاً غیرفعال است.", show_alert=True)
    if a == "stars":
        await bot.send_invoice(uid, title="پلن ویژه", description=f"اشتراک ویژه {S('special_days')} روزه با هوش مصنوعی", payload=f"sp:{uid}", currency="XTR", prices=[LabeledPrice(label="پلن ویژه", amount=stars_price(uid))], provider_token="")
        return await c.answer()
    if a == "card":
        if not S("card_number"): return await c.answer("روش کارت‌به‌کارت هنوز تنظیم نشده.", show_alert=True)
        set_flow(uid, s="rcpt"); return await show(c, f"💳 <b>کارت‌به‌کارت</b>\n\nمبلغ: <b>{card_price(uid):,} تومان</b>\nشماره کارت:\n<code>{html.escape(S('card_number'))}</code>\nبه نام: {html.escape(S('card_holder'))}\n\nپس از واریز، <b>عکس رسید</b> را همین‌جا بفرستید.", [[B("❌ انصراف", "m:buy")]])
@dp.pre_checkout_query()
async def pre_checkout(pq: PreCheckoutQuery): await pq.answer(ok=pq.invoice_payload.startswith("sp:") and pq.from_user.id == int(pq.invoice_payload[3:]))
@dp.message(F.successful_payment)
async def paid(m: Message):
    uid = m.from_user.id; sp = m.successful_payment; grant_special(uid, S("special_days")); consume_disc(uid)
    run("INSERT INTO payments(user_id,method,amount,status,created,ref) VALUES(?,?,?,?,?,?)", (uid, "stars", sp.total_amount, "paid", int(time.time()), sp.telegram_payment_charge_id))
    await m.answer(f"✅ پرداخت موفق بود؛ پلن ویژه {S('special_days')} روزه فعال شد. 🎉", reply_markup=Kb(inline_keyboard=[[B("🤖 شروع با هوش مصنوعی", "m:ai")]]))
    try: await bot.send_message(OWNER_ID, f"💰 خرید با استارز: {html.escape(m.from_user.full_name)} • <code>{uid}</code> • {sp.total_amount}⭐️")
    except Exception: pass

# ── تنظیمات (مالک) ──
@dp.callback_query(F.data.startswith("s:"))
async def settings_cb(c: CallbackQuery):
    uid = c.from_user.id
    if not owner(uid): return await c.answer("فقط مالک.", show_alert=True)
    p = c.data.split(":")
    if p[1] == "list":
        clear_flow(uid); return await show(c, "⚙️ <b>تنظیمات فروش و هوش مصنوعی</b>\nروی هر مورد بزنید تا مقدار جدید را وارد کنید:",
            [[B(f"{v[0]}: {(str(S(k)) or '—')[:18]}", f"s:e:{i}")] for i, (k, v) in enumerate(SET.items())] + [[B("🔙 مدیریت", "a:home")]])
    if p[1] == "e":
        i = int(p[2]); set_flow(uid, s="set", i=i); k = list(SET)[i]
        return await show(c, f"✏️ <b>{SET[k][0]}</b>\nمقدار فعلی: <code>{html.escape(str(S(k)))}</code>\n\nمقدار جدید را بفرستید:", [[B("❌ انصراف", "s:list")]])

# ══ نسخه نهایی: تقویم محتوا، تیکت، کد تخفیف، رشد کانال، گزارش‌ها ══
DAYS_FA = ["دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه", "یکشنبه"]
def slots(c, n):
    hrs = sorted(json.loads(c["times"] or "[20]")) or [20]; now = time.time(); day0 = (now + 12600) // 86400 * 86400; out = []; d = 0
    while len(out) < n and d < 60:
        for h in hrs:
            ts = int(day0 + d * 86400 + h * 3600 - 12600)
            if ts > now + 600 and len(out) < n: out.append(ts)
        d += 1
    return out
def slot_label(ts): g = time.gmtime(int(ts) + 12600); return f"{DAYS_FA[g.tm_wday]} {g.tm_hour:02d}:{g.tm_min:02d}"
def batch_rows(cid): return q("SELECT id,text,run_at FROM drafts WHERE chat_id=? AND status='batch' ORDER BY run_at", (cid,))
def batch_text(cid):
    rs = batch_rows(cid); title = (q("SELECT title FROM channels WHERE chat_id=?", (cid,)) or [[""]])[0][0]
    body = "\n\n".join(f"<b>{i + 1}) {slot_label(r['run_at'])}</b>\n{html.escape(plain(r['text'])[:80])}…" for i, r in enumerate(rs))
    return f"📅 <b>پست‌های هفته</b> — {html.escape(title or '')}\n{HR}\n{body}\n\nاگر تأیید کنی، هر پست سر ساعتش خودکار منتشر می‌شود."
def batch_kb(cid): return [[B("✅ تأیید همه و زمان‌بندی", f"bt:ok:{cid}")], pair(B("👁 مشاهده و ویرایش", f"bt:l:{cid}"), B("🗑 حذف همه", f"bt:no:{cid}")), [B("🔙 تنظیمات کانال", f"ai:c:{cid}")]]
def remaining_ai(uid):
    if owner(uid): return 30
    return max(0, S("quota_special") - ai_today(uid)) if premium(uid) else trial_left(uid)
async def make_batch(uid, cid, n):
    made = 0; err = None
    for ts in slots(ensure_cfg(cid, uid), n):
        ok, why = can_ai(uid)
        if not ok: err = why; break
        try: t, _ = await gen_text(ensure_cfg(cid, uid))
        except ValueError as e: err = str(e); break
        except Exception: err = "fail"; break
        ai_use(uid); run("INSERT INTO drafts(owner,chat_id,text,status,created,run_at) VALUES(?,?,?,?,?,?)", (uid, cid, t, "batch", int(time.time()), ts)); made += 1
    try:
        if made: await bot.send_message(uid, batch_text(cid), reply_markup=Kb(inline_keyboard=batch_kb(cid)))
        else: await bot.send_message(uid, "❌ " + ERR.get(err, ERR["fail"]))
    except Exception: pass
def batch_list(uid):
    return [{"id": r["id"], "chat_id": r["chat_id"], "html": r["text"], "t": r["run_at"], "ch": r["title"] or "—"} for r in q(
        "SELECT d.id,d.chat_id,d.text,d.run_at,c.title FROM drafts d LEFT JOIN channels c ON c.chat_id=d.chat_id WHERE d.owner=? AND d.status='batch' ORDER BY d.run_at", (uid,))]
def approve_batch(uid, cid):
    n = 0; now = int(time.time())
    for i, d in enumerate(q("SELECT * FROM drafts WHERE chat_id=? AND owner=? AND status='batch' ORDER BY run_at", (cid, uid))):
        t = d["run_at"] if d["run_at"] and d["run_at"] > now + 60 else now + 300 * (i + 1)
        add_post(uid, cid, d["text"], "scheduled", t); run("UPDATE drafts SET status='scheduled' WHERE id=?", (d["id"],)); n += 1
    return n
@dp.callback_query(F.data.startswith("bt:"))
async def bt_cb(c: CallbackQuery):
    if not await gate(c): return
    uid = c.from_user.id; p = c.data.split(":"); k = p[1]
    if k in ("menu", "l", "ok", "no", "gen"):
        cid = int(p[2])
        if not q("SELECT 1 FROM channels WHERE chat_id=? AND owner=?", (cid, uid)): return await c.answer("کانال پیدا نشد.", show_alert=True)
        has = bool(batch_rows(cid))
    if k == "menu":
        if has: return await show(c, batch_text(cid), batch_kb(cid))
        return await show(c, f"📅 <b>پست‌های هفته</b>\n{HR}\nهوش مصنوعی چند پست را یک‌جا می‌نویسد و برای ساعت‌های تنظیم‌شده‌ی کانال برنامه‌ریزی می‌کند. تو بررسی و تأیید می‌کنی؛ بعد خودکار سر وقت منتشر می‌شوند.\n\nچند پست بنویسم؟  (سهمیه‌ی باقی‌مانده: {remaining_ai(uid)})",
                          [[B("۷ پست", f"bt:gen:{cid}:7"), B("۵ پست", f"bt:gen:{cid}:5"), B("۳ پست", f"bt:gen:{cid}:3")], [B("🔙 تنظیمات کانال", f"ai:c:{cid}")]])
    if k == "gen":
        if has: return await c.answer("ابتدا پست‌های آماده را تأیید یا حذف کن.", show_alert=True)
        ok, why = can_ai(uid)
        if not ok: return await c.answer(ERR[why], show_alert=True)
        n = min(int(p[3]), remaining_ai(uid))
        if n <= 0: return await c.answer(ERR["quota"], show_alert=True)
        asyncio.create_task(make_batch(uid, cid, n)); return await show(c, f"⏳ در حال نوشتن {n} پست…\nحدود یک دقیقه طول می‌کشد؛ وقتی آماده شد همین‌جا خبر می‌دهم.", [[B("🔙 تنظیمات کانال", f"ai:c:{cid}")]])
    if k == "ok":
        n = approve_batch(uid, cid); return await show(c, f"✅ {n} پست زمان‌بندی شد و سر وقت منتشر می‌شود.", [[B("🕒 صف انتشار", "m:queue")], [B("🔙 تنظیمات کانال", f"ai:c:{cid}")]])
    if k == "no":
        run("UPDATE drafts SET status='rejected' WHERE chat_id=? AND owner=? AND status='batch'", (cid, uid)); return await show(c, "🗑 پست‌های آماده حذف شدند.", [[B("📅 ساخت دوباره", f"bt:menu:{cid}")], [B("🔙 تنظیمات کانال", f"ai:c:{cid}")]])
    if k == "l":
        rs = batch_rows(cid)
        return await show(c, f"👁 <b>پست‌های هفته</b>\n{HR}\nروی هر پست بزن:", [[B(f"{slot_label(r['run_at'])} — {plain(r['text'])[:22]}", f"bt:v:{r['id']}")] for r in rs] + [[B("🔙 بازگشت", f"bt:menu:{cid}")]])
    did = int(p[2]); d = q("SELECT * FROM drafts WHERE id=? AND owner=? AND status='batch'", (did, uid))
    if not d: return await c.answer("این پست دیگر موجود نیست.", show_alert=True)
    d = d[0]; cid = d["chat_id"]
    if k == "v": return await show(c, f"🗓 <b>{slot_label(d['run_at'])}</b>\n{HR}\n{d['text'][:3500]}", [pair(B("✏️ ویرایش", f"bt:e:{did}"), B("🗑 حذف", f"bt:d:{did}")), [B("🔙 فهرست", f"bt:l:{cid}")]])
    if k == "d":
        run("UPDATE drafts SET status='rejected' WHERE id=?", (did,)); c = c.model_copy(update={"data": f"bt:l:{cid}" if batch_rows(cid) else f"bt:menu:{cid}"}); return await bt_cb(c)
    if k == "e": set_flow(uid, s="bt_edit", did=did); await c.message.answer("✏️ متن جدید این پست را بفرست:"); await c.answer()

# ── تیکت پشتیبانی ──
async def tk_home(ev):
    uid = ev.from_user.id; ts = q("SELECT id FROM tickets WHERE user_id=? AND status='open' ORDER BY id DESC LIMIT 3", (uid,))
    await show(ev, f"🆘 <b>پشتیبانی</b>\n{HR}\nسؤال، مشکل یا پیشنهادت را بنویس؛ پاسخ را همین‌جا می‌گیری.\nتیکت‌های باز: {len(ts)}",
               [[B("✉️ ارسال پیام جدید", "tk:new")]] + [[B(f"💬 تیکت #{t['id']} — پاسخ دادن", f"tk:u:{t['id']}")] for t in ts] + [BACK])
async def tk_forward(tid, uid, name, text):
    try: await bot.send_message(OWNER_ID, f"🎫 <b>تیکت #{tid}</b>\nاز: {html.escape(name)} • <code>{uid}</code>\n{HR}\n{html.escape(text)}", reply_markup=Kb(inline_keyboard=[pair(B("↩️ پاسخ", f"tk:r:{tid}"), B("✅ بستن", f"tk:c:{tid}"))]))
    except Exception: pass
@dp.callback_query(F.data.startswith("tk:"))
async def tk_cb(c: CallbackQuery):
    uid = c.from_user.id; p = c.data.split(":"); k = p[1]
    if k in ("r", "c", "list"):
        if not owner(uid): return await c.answer("فقط مالک.", show_alert=True)
    elif not await gate(c): return
    if k == "home": clear_flow(uid); return await tk_home(c)
    if k == "new":
        if q("SELECT COUNT(*) n FROM tickets WHERE user_id=? AND status='open'", (uid,))[0]["n"] >= 3: return await c.answer("سه تیکت باز داری؛ ابتدا در یکی از آن‌ها ادامه بده.", show_alert=True)
        if q("SELECT 1 FROM tickets WHERE user_id=? AND created>?", (uid, int(time.time()) - 60)): return await c.answer("کمی صبر کن و دوباره امتحان کن.", show_alert=True)
        set_flow(uid, s="tk_new"); return await show(c, "✉️ پیام خودت را بنویس و بفرست (حداکثر ۱۰۰۰ کاراکتر):", [[B("❌ انصراف", "tk:home")]])
    if k == "u":
        t = q("SELECT id FROM tickets WHERE id=? AND user_id=? AND status='open'", (int(p[2]), uid))
        if not t: return await c.answer("این تیکت بسته شده است.", show_alert=True)
        set_flow(uid, s="tk_user", id=t[0]["id"]); return await show(c, f"💬 پیام جدیدت برای تیکت #{t[0]['id']} را بنویس:", [[B("❌ انصراف", "tk:home")]])
    if k == "list":
        ts = q("SELECT t.id,a.first_name FROM tickets t LEFT JOIN access a ON a.user_id=t.user_id WHERE t.status='open' ORDER BY t.last_at DESC LIMIT 10")
        return await show(c, f"🎫 <b>تیکت‌های باز</b> ({len(ts)})\n{HR}", [[B(f"#{t['id']} — {t['first_name'] or ''}", f"tk:r:{t['id']}")] for t in ts] + [[B("🔙 مدیریت", "a:home")]])
    tid = int(p[2]); t = q("SELECT * FROM tickets WHERE id=?", (tid,))
    if not t: return await c.answer("تیکت پیدا نشد.", show_alert=True)
    if k == "r":
        last = q("SELECT from_owner,text FROM ticket_msgs WHERE ticket_id=? ORDER BY id DESC LIMIT 3", (tid,))[::-1]
        hist = "\n".join(("🟢 " if m["from_owner"] else "👤 ") + html.escape(m["text"][:200]) for m in last)
        set_flow(uid, s="tk_reply", id=tid); return await show(c, f"↩️ <b>پاسخ به تیکت #{tid}</b>\n{HR}\n{hist}\n\nپاسخ را بنویس:", [[B("❌ انصراف", "tk:list")]])
    if k == "c":
        run("UPDATE tickets SET status='closed' WHERE id=?", (tid,))
        try: await bot.send_message(t[0]["user_id"], f"✅ تیکت #{tid} بسته شد. اگر مشکل ادامه داشت، تیکت جدید بساز.")
        except Exception: pass
        await c.answer("بسته شد")
        try: await c.message.edit_text((c.message.html_text or "") + "\n\n✅ بسته شد", reply_markup=None)
        except Exception: pass

# ── کد تخفیف و هدیه ──
def disc(uid):
    v = setting(f"disc:{uid}", ""); return int(v.split(":")[1]) if ":" in v else 0
def card_price(uid): return int(re.sub(r"\D", "", S("price_card")) or 0) * (100 - disc(uid)) // 100
def stars_price(uid): return max(1, S("price_stars") * (100 - disc(uid)) // 100)
def consume_disc(uid):
    v = setting(f"disc:{uid}", "")
    if ":" in v:
        code = v.split(":")[0]; run("INSERT OR IGNORE INTO code_uses VALUES(?,?)", (code, uid)); run("UPDATE codes SET used=used+1 WHERE code=?", (code,)); run("DELETE FROM settings WHERE key=?", (f"disc:{uid}",))
@dp.callback_query(F.data.startswith("cd:"))
async def cd_cb(c: CallbackQuery):
    uid = c.from_user.id; p = c.data.split(":"); k = p[1]
    if k == "enter":
        if not await gate(c): return
        set_flow(uid, s="code"); return await show(c, f"🎟 <b>کد تخفیف یا هدیه</b>\n{HR}\nکد را بفرست:", [[B("❌ انصراف", "m:buy")]])
    if not owner(uid): return await c.answer("فقط مالک.", show_alert=True)
    if k == "list":
        cs = q("SELECT * FROM codes ORDER BY created DESC LIMIT 15")
        txt = "\n".join(f"<code>{x['code']}</code> • {'تخفیف ' + str(x['value']) + '٪' if x['kind'] == 'd' else 'هدیه ' + str(x['value']) + ' روز'} • {x['used']}/{x['max_uses']}" for x in cs) or "کدی ساخته نشده."
        return await show(c, f"🎟 <b>کدها</b>\n{HR}\n{txt}", [[B("➕ ساخت کد", "cd:new")]] + [[B(f"🗑 {x['code']}", f"cd:del:{x['code']}")] for x in cs] + [[B("🔙 مدیریت", "a:home")]])
    if k == "new":
        set_flow(uid, s="code_new"); return await show(c, "➕ <b>ساخت کد</b>\nبا این قالب بفرست:\n<code>نام نوع مقدار تعداد</code>\n\nتخفیف ۳۰ درصد برای ۱۰ نفر:\n<code>OFF30 d 30 10</code>\nهدیه‌ی ۷ روز ویژه برای ۵ نفر:\n<code>FREE7 g 7 5</code>", [[B("❌ انصراف", "cd:list")]])
    if k == "del": run("DELETE FROM codes WHERE code=?", (p[2],)); audit(uid, "code_del", p[2]); return await cd_cb(c.model_copy(update={"data": "cd:list"}))

# ── کارهای پس‌زمینه: رشد کانال، یادآوری تمدید، گزارش هفتگی ──
def growth(cid, n=30): return [{"d": r["day"] * 86400, "m": r["members"]} for r in reversed(q("SELECT day,members FROM ch_stats WHERE chat_id=? ORDER BY day DESC LIMIT ?", (cid, n)))]
def delta7(cid, now_m):
    today = int(time.time()) // 86400; r = q("SELECT members FROM ch_stats WHERE chat_id=? AND day<=? ORDER BY day DESC LIMIT 1", (cid, today - 7))
    if not r:
        r = q("SELECT members FROM ch_stats WHERE chat_id=? ORDER BY day LIMIT 1", (cid,))
        if not r or q("SELECT COUNT(*) n FROM ch_stats WHERE chat_id=?", (cid,))[0]["n"] < 2: return None
    return now_m - r[0][0]
async def record_stats():
    day = int(time.time()) // 86400
    for ch in q("SELECT chat_id FROM channels"):
        if q("SELECT 1 FROM ch_stats WHERE chat_id=? AND day=?", (ch["chat_id"], day)): continue
        try: n = await bot.get_chat_member_count(ch["chat_id"])
        except Exception: continue
        run("INSERT OR IGNORE INTO ch_stats VALUES(?,?,?)", (ch["chat_id"], day, n)); run("UPDATE channels SET members=? WHERE chat_id=?", (n, ch["chat_id"])); await asyncio.sleep(0.3)
async def reminders():
    now = int(time.time())
    for r in q("SELECT user_id,special_until FROM access WHERE special_until>? AND special_until<?", (now, now + 3 * 86400)):
        if setting(f"rem:{r['user_id']}", "") == str(r["special_until"]): continue
        set_setting(f"rem:{r['user_id']}", r["special_until"]); left = (r["special_until"] - now) // 86400 + 1
        try: await bot.send_message(r["user_id"], f"⏰ <b>یادآوری تمدید</b>\nپلن ویژه‌ات حدود {left} روز دیگر تمام می‌شود. برای ادامه‌ی هوش مصنوعی و سقف بالاتر، تمدید کن.", reply_markup=Kb(inline_keyboard=[[B("💎 تمدید پلن ویژه", "m:buy")]]))
        except Exception: pass
async def weekly_reports():
    g = time.gmtime(time.time() + 12600)
    if g.tm_wday != 4 or g.tm_hour < 18: return
    key = time.strftime("%Y%W", g)
    if setting("wr_last", "") == key: return
    set_setting("wr_last", key); t0 = int(time.time()) - 7 * 86400
    for u in q("SELECT DISTINCT owner FROM channels"):
        uid = u["owner"]
        if setting(f"wr:{uid}") != "1": continue
        st = {r["status"]: r["n"] for r in q("SELECT status,COUNT(*) n FROM posts WHERE owner=? AND created>? GROUP BY status", (uid, t0))}
        hrs = [0] * 24
        for r in q("SELECT created FROM posts WHERE owner=? AND status='sent' AND created>?", (uid, t0 - 23 * 86400)): hrs[((r["created"] + 12600) // 3600) % 24] += 1
        gl = []
        for ch in q("SELECT chat_id,title,members FROM channels WHERE owner=?", (uid,)):
            d = delta7(ch["chat_id"], ch["members"]); gl.append(f"• {html.escape(ch['title'] or '')}: {ch['members']} عضو" + (f" ({'+' if d >= 0 else ''}{d})" if d is not None else ""))
        best = f"\n⏱ بهترین ساعت انتشار: {hrs.index(max(hrs))}" if max(hrs) else ""
        try: await bot.send_message(uid, f"📬 <b>گزارش هفتگی</b>\n{HR}\n✅ منتشرشده: {st.get('sent', 0)}\n❌ ناموفق: {st.get('failed', 0)}\n🕒 در صف: {st.get('scheduled', 0)}\n\n" + "\n".join(gl) + best)
        except Exception: pass
        await asyncio.sleep(0.05)
async def bg_loop():
    await asyncio.sleep(60)
    while True:
        try: await record_stats(); await reminders(); await weekly_reports()
        except Exception: log.exception("bg")
        await asyncio.sleep(1800)

# ── API: تنظیمات کانال و تقویم محتوا ──
async def api_ai_cfg(request):
    uid = request["user"]["id"]
    try:
        b = await request.json() if request.method == "POST" else {}; cid = int(b.get("chat_id") or request.query.get("chat_id", 0))
    except Exception: return jerr("درخواست نامعتبر است")
    if not q("SELECT 1 FROM channels WHERE chat_id=? AND owner=?", (cid, uid)): return jerr("کانال پیدا نشد", 404)
    c = ensure_cfg(cid, uid); lim = 10 if owner(uid) else max(1, S("quota_special")) if premium(uid) else 1
    if request.method == "POST":
        up = {}
        if "mode" in b:
            if b["mode"] not in ("manual", "smart"): return jerr("حالت نامعتبر است")
            up["mode"] = b["mode"]
        if "topic" in b: up["topic"] = str(b["topic"]).strip()[:300]
        if "tone" in b:
            if b["tone"] not in TONES: return jerr("لحن نامعتبر است")
            up["tone"] = b["tone"]
        if "per_day" in b:
            n = int(b["per_day"])
            if n not in PRESETS or n > lim: return jerr("تعداد پست در روز مجاز نیست")
            up["per_day"] = n; up["times"] = json.dumps(PRESETS[n])
        if "publish" in b:
            if b["publish"] not in ("draft", "auto"): return jerr("حالت انتشار نامعتبر است")
            up["publish"] = b["publish"]
        for f in ("support", "chan"):
            if f in b:
                h = norm_handle(str(b[f]))
                if h is None: return jerr("آیدی نامعتبر است؛ مثل @name بنویسید")
                up[f] = h
        if "sig" in b: up["sig"] = str(b["sig"]).strip()[:200]
        if "sig_every" in b:
            if int(b["sig_every"]) not in (1, 2, 3, 5): return jerr("مقدار نامعتبر است")
            up["sig_every"] = int(b["sig_every"])
        if up:
            run("UPDATE ai_cfg SET " + ",".join(f"{k}=?" for k in up) + " WHERE chat_id=?", (*up.values(), cid)); up_c = True
        c = ensure_cfg(cid, uid)
    d = {k: c[k] for k in ("mode", "topic", "tone", "per_day", "publish", "support", "chan", "sig", "sig_every", "enabled")}
    return web.json_response({**d, "tones": TONES, "presets": [n for n in PRESETS if n <= lim], "samples": q("SELECT COUNT(*) n FROM ai_samples WHERE chat_id=?", (cid,))[0]["n"], "growth": growth(cid)})
async def api_ai_batch(request):
    uid = request["user"]["id"]
    try: b = await request.json(); act = b["action"]
    except Exception: return jerr("درخواست نامعتبر است")
    if act in ("edit", "delete"):
        d = q("SELECT id FROM drafts WHERE id=? AND owner=? AND status='batch'", (int(b.get("id", 0)), uid))
        if not d: return jerr("پست پیدا نشد", 404)
        if act == "delete": run("UPDATE drafts SET status='rejected' WHERE id=?", (d[0]["id"],))
        else:
            t = clean_html(str(b.get("text", "")))
            if not plain(t).strip() or len(plain(t)) > MAX_LEN: return jerr("متن نامعتبر است")
            run("UPDATE drafts SET text=? WHERE id=?", (t, d[0]["id"]))
        return web.json_response({"ok": True})
    try: cid = int(b["chat_id"])
    except Exception: return jerr("درخواست نامعتبر است")
    if not q("SELECT 1 FROM channels WHERE chat_id=? AND owner=?", (cid, uid)): return jerr("کانال پیدا نشد", 404)
    if act == "approve": return web.json_response({"ok": True, "n": approve_batch(uid, cid)})
    if act == "discard": run("UPDATE drafts SET status='rejected' WHERE chat_id=? AND owner=? AND status='batch'", (cid, uid)); return web.json_response({"ok": True})
    if act == "generate":
        if batch_rows(cid): return jerr("ابتدا پست‌های آماده را تأیید یا حذف کنید")
        ok, why = can_ai(uid)
        if not ok: return jerr(ERR[why], 403)
        n = min(int(b.get("n", 5)), remaining_ai(uid))
        if n <= 0: return jerr(ERR["quota"], 403)
        asyncio.create_task(make_batch(uid, cid, n)); return web.json_response({"ok": True, "n": n})
    return jerr("عملیات نامعتبر است")

@dp.message(F.chat.type == ChatType.PRIVATE)
async def flows(m: Message):
    uid = m.from_user.id; f = get_flow(uid); s = f.get("s")
    if not s or (not owner(uid) and s != "text" and s not in AI_FLOWS): return
    if s in AI_FLOWS: return await ai_flow(m, f)
    if s == "text":
        if not await gate(m): return
        txt = clean_html(m.html_text or "") if (m.text or m.caption) else ""; media = mtype = None
        if m.photo: media, mtype = "tg:" + m.photo[-1].file_id, "photo"
        elif m.video: media, mtype = "tg:" + m.video.file_id, "video"
        if not (plain(txt).strip() or media) or len(plain(txt)) > (1024 if media else MAX_LEN): return await m.answer("متن نامعتبر یا طولانی است (با عکس/ویدیو حداکثر ۱۰۲۴ کاراکتر).")
        ch = q("SELECT chat_id,title FROM channels WHERE owner=? ORDER BY created DESC LIMIT 20", (uid,))
        if not ch: clear_flow(uid); return await m.answer("کانالی ثبت نشده؛ ربات را ادمین کانال کنید.")
        set_flow(uid, s="pick", text=txt, media=media, mtype=mtype)
        return await show(m, "📢 <b>کانال مقصد</b> را انتخاب کن:", [[B((x["title"] or "کانال")[:40], f"p:pub:{x['chat_id']}")] for x in ch] + [[B("❌ انصراف", "m:main")]])
    if s == "bc":
        if not m.text: return
        set_flow(uid, s="bcc", text=clean_html(m.html_text or "")); n = q("SELECT COUNT(*) n FROM access WHERE status='approved'")[0]["n"]
        return await show(m, f"ارسال این پیام برای {n} کاربر؟\n\n{clean_html(m.html_text or '')}", [pair(B("✅ ارسال", "a:bcgo"), B("❌ انصراف", "a:home"))])
    if s == "fj" and owner(uid):
        o = getattr(m, "forward_origin", None); ref = str(o.chat.id) if o and getattr(o, "chat", None) else (m.text or "")
        try: t = await add_force(ref); audit(uid, "force_add", t); clear_flow(uid); await show(m, f"✅ «{html.escape(t or '')}» اضافه شد.", [[B("🔒 جوین اجباری", "a:fj")]])
        except Exception as e: await m.answer("❌ " + (str(e) if isinstance(e, ValueError) else "کانال پیدا نشد؛ ربات باید در آن ادمین باشد."))

@dp.my_chat_member()
async def on_member(ev: ChatMemberUpdated):
    ch = ev.chat
    if ch.type != ChatType.CHANNEL: return
    n = ev.new_chat_member
    if n.status == "administrator" and getattr(n, "can_post_messages", True):
        if status_of(ev.from_user.id) != "approved": return
        try: mem = await bot.get_chat_member_count(ch.id)
        except Exception: mem = 0
        run("""INSERT INTO channels VALUES(?,?,?,?,?,?) ON CONFLICT(chat_id) DO UPDATE SET owner=excluded.owner,title=excluded.title,username=excluded.username,members=excluded.members""",
            (ch.id, ev.from_user.id, ch.title, ch.username, mem, int(time.time())))
        try: await bot.send_message(ev.from_user.id, f"✅ کانال <b>{html.escape(ch.title or '')}</b> اضافه شد.", reply_markup=Kb(inline_keyboard=[[B("🚀 باز کردن پنل", app=URL)]]))
        except Exception: pass
    elif n.status in ("left", "kicked", "member", "restricted"): run("DELETE FROM channels WHERE chat_id=?", (ch.id,))

async def main():
    app = web.Application(middlewares=[mw], client_max_size=45 * 2**20)
    app.add_routes([web.get("/", index), web.get("/api/state", api_state), web.get("/api/photo", api_photo), web.post("/api/post", api_post), web.post("/api/upload", api_upload), web.get("/api/posts", api_posts), web.post("/api/posts", api_posts_act),
        web.get("/api/queue", api_queue), web.post("/api/queue", api_queue_act), web.get("/api/admin/overview", api_adm_overview),
        web.get("/api/admin/users", api_adm_users), web.post("/api/admin/user", api_adm_user), web.post("/api/admin/broadcast", api_adm_broadcast),
        web.get("/api/admin/activity", api_adm_activity), web.get("/api/admin/user_detail", api_adm_detail), web.post("/api/admin/post", api_adm_post), web.post("/api/admin/setting", api_adm_setting),
        web.get("/api/ai", api_ai), web.get("/api/ai/cfg", api_ai_cfg), web.post("/api/ai/cfg", api_ai_cfg), web.post("/api/ai/batch", api_ai_batch), web.post("/api/ai/draft", api_ai_draft), web.post("/api/ai/toggle", api_ai_toggle), web.get("/api/admin/settings", api_adm_settings), web.post("/api/admin/settings", api_adm_settings),
        web.get("/api/admin/force", api_adm_force), web.post("/api/admin/force", api_adm_force)])
    runner = web.AppRunner(app); await runner.setup(); await web.TCPSite(runner, "0.0.0.0", PORT).start()
    await bot.delete_webhook(drop_pending_updates=False)
    await bot.set_chat_menu_button(menu_button=MenuButtonWebApp(text="پنل", web_app=WebAppInfo(url=URL)))
    tasks = [asyncio.create_task(scheduler()), asyncio.create_task(backup_loop()), asyncio.create_task(report_loop()), asyncio.create_task(ai_loop()), asyncio.create_task(bg_loop())]
    try: await dp.start_polling(bot, allowed_updates=["message", "callback_query", "my_chat_member", "channel_post", "pre_checkout_query"])
    finally:
        for t in tasks: t.cancel()
        await runner.cleanup(); await bot.session.close()
if __name__ == "__main__": asyncio.run(main())
