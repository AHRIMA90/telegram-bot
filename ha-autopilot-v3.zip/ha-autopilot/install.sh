#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v docker >/dev/null 2>&1; then
  echo ">> نصب Docker ..."
  curl -fsSL https://get.docker.com | sh
fi
echo
read -rp "توکن ربات (از BotFather): " TOKEN
read -rp "دامنه (مثال: panel.example.com — باید به IP این سرور وصل باشد): " DOMAIN
DOMAIN="${DOMAIN#https://}"; DOMAIN="${DOMAIN%/}"
cat > .env <<EOF
BOT_TOKEN=$TOKEN
DOMAIN=$DOMAIN
WEBAPP_URL=https://$DOMAIN
OWNER_ID=8553939238
ADMIN_IDS=8389212775
EOF
docker compose up -d --build
echo
echo "✅ انجام شد. حالا در تلگرام به ربات پیام /start بده."
echo "   لاگ‌ها: docker compose logs -f bot"
